// app/student/page.tsx
'use client'

import { useState, useEffect } from 'react'
import { Offer, OfferType, UserRole } from '@/types'
import { ApplicationFormData } from '@/types/student'
import StatCard from '@/components/shared/StatCard'
import OfferCard from '@/components/shared/OfferCard'
import ApplicationModal from '@/components/shared/ApplicationModal'
import OfferDetailsModal from '@/components/shared/OfferDetailsModal'
import ApplicationResultModal from '@/components/shared/ApplicationResultModal'
import ProtectedRoute from '@/components/auth/ProtectedRoute'
import { ApplicationAnalyzer, AnalysisResult } from '@/lib/services/applicationAnalyzer'

// Mock data (replace with API call)
const MOCK_OFFERS: Offer[] = [
  { id: 1, title: 'PFE — Deep Learning for Image Recognition', company: 'Esprit', type: OfferType.PFE, status: 'open' as any, deadline: '2025-03-15', skills: ['Python', 'TensorFlow', 'CNN'], description: 'Develop a CNN-based model for real-time medical image classification.', postedAt: '2025-01-10', applicantCount: 8 },
  { id: 2, title: 'Summer Intern — Web Developer', company: 'Sopra Steria', type: OfferType.SUMMER, status: 'open' as any, deadline: '2025-05-01', skills: ['React', 'Node.js', 'MongoDB'], description: 'Build customer-facing dashboards and integrate REST APIs for internal tools.', postedAt: '2025-01-12', applicantCount: 12 },
  { id: 3, title: 'Junior Software Engineer', company: 'Banka de Tunisie', type: OfferType.JOB, status: 'open' as any, deadline: '2025-04-10', skills: ['Java', 'Spring Boot', 'SQL'], description: 'Join our digital transformation team. Work on microservices architecture for banking.', postedAt: '2025-01-08', applicantCount: 5 },
  { id: 4, title: 'PFE — IoT Smart Campus', company: "ENET'COM Labs", type: OfferType.PFE, status: 'open' as any, deadline: '2025-03-20', skills: ['Arduino', 'MQTT', 'Node.js'], description: 'Design and deploy IoT sensors for smart energy monitoring across campus buildings.', postedAt: '2025-01-14', applicantCount: 6 },
  { id: 5, title: 'Summer Intern — Data Scientist', company: 'Orange Tunisia', type: OfferType.SUMMER, status: 'open' as any, deadline: '2025-04-25', skills: ['Python', 'Pandas', 'Scikit-learn'], description: 'Analyze telecom usage data to improve network performance and customer experience.', postedAt: '2025-01-11', applicantCount: 9 },
  { id: 6, title: 'DevOps Engineer — Full Time', company: 'Witup', type: OfferType.JOB, status: 'open' as any, deadline: '2025-04-05', skills: ['Docker', 'Kubernetes', 'AWS'], description: 'Manage CI/CD pipelines and cloud infrastructure for a fast-growing SaaS platform.', postedAt: '2025-01-09', applicantCount: 4 },
]

export default function StudentPage() {
  const [filter, setFilter] = useState<OfferType | 'all'>('all')
  const [offers, setOffers] = useState<Offer[]>(MOCK_OFFERS)
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null)
  const [showApplicationModal, setShowApplicationModal] = useState(false)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [showResultModal, setShowResultModal] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null)
  const [applicationCount, setApplicationCount] = useState(5)

  const filteredOffers = filter === 'all' 
    ? offers 
    : offers.filter(o => o.type === filter)

  const pfeCount = offers.filter(o => o.type === OfferType.PFE).length
  const summerCount = offers.filter(o => o.type === OfferType.SUMMER).length
  const jobCount = offers.filter(o => o.type === OfferType.JOB).length

  const handleApply = (offer: Offer) => {
    setSelectedOffer(offer)
    setShowApplicationModal(true)
  }

  const handleDetails = (offer: Offer) => {
    setSelectedOffer(offer)
    setShowDetailsModal(true)
  }

  const handleApplicationSubmit = (data: ApplicationFormData) => {
    if (!selectedOffer) return

    console.log('Application submitted:', data)
    
    // Analyser la candidature avec l'IA
    const result = ApplicationAnalyzer.analyze(data, selectedOffer)
    
    setAnalysisResult(result)
    setApplicationCount(prev => prev + 1)
    setShowApplicationModal(false)
    
    // Afficher le modal de résultat après une courte pause
    setTimeout(() => {
      setShowResultModal(true)
    }, 300)
  }

  return (
    <ProtectedRoute allowedRole={UserRole.STUDENT}>
      <section className="relative z-10 min-h-screen px-10 pt-28 pb-16">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-9">
            <h1 className="font-display text-3xl font-bold text-text-white">
              🎓 Student <span className="text-orange-light">Dashboard</span>
            </h1>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard value={pfeCount} label="PFE Offers" />
            <StatCard value={summerCount} label="Summer Internships" />
            <StatCard value={jobCount} label="Job Opportunities" />
            <StatCard value={applicationCount} label="Applications Sent" />
          </div>

          {/* Filter tabs */}
          <div className="flex gap-2 mb-7 flex-wrap">
            {[
              { label: 'All Offers', value: 'all' as const },
              { label: 'PFE Projects', value: OfferType.PFE },
              { label: 'Summer Internships', value: OfferType.SUMMER },
              { label: 'Job Opportunities', value: OfferType.JOB },
            ].map(tab => (
              <button
                key={tab.value}
                onClick={() => setFilter(tab.value)}
                className={`
                  px-5 py-2 rounded-full font-body text-sm font-semibold tracking-wide transition-all duration-300
                  ${filter === tab.value
                    ? 'bg-gradient-to-r from-blue-accent to-orange-main border-transparent text-white'
                    : 'bg-blue-mid/50 border border-blue-accent/20 text-text-dim hover:bg-gradient-to-r hover:from-blue-accent hover:to-orange-main hover:text-white'}
                `}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Offers grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredOffers.map(offer => (
              <OfferCard 
                key={offer.id} 
                offer={offer} 
                onApply={() => handleApply(offer)}
                onDetails={() => handleDetails(offer)}
              />
            ))}
          </div>
        </div>

        {/* Modals */}
        {showApplicationModal && selectedOffer && (
          <ApplicationModal
            offer={selectedOffer}
            onClose={() => {
              setShowApplicationModal(false)
              setSelectedOffer(null)
            }}
            onSubmit={handleApplicationSubmit}
          />
        )}

        {showDetailsModal && selectedOffer && (
          <OfferDetailsModal
            offer={selectedOffer}
            onClose={() => {
              setShowDetailsModal(false)
              setSelectedOffer(null)
            }}
            onApply={() => {
              setShowDetailsModal(false)
              handleApply(selectedOffer)
            }}
          />
        )}

        {showResultModal && analysisResult && selectedOffer && (
          <ApplicationResultModal
            result={analysisResult}
            offer={selectedOffer}
            onClose={() => {
              setShowResultModal(false)
              setAnalysisResult(null)
              setSelectedOffer(null)
            }}
          />
        )}
      </section>
    </ProtectedRoute>
  )
}
