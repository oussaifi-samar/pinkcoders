// app/admin/page.tsx
'use client'

import { useState } from 'react'
import { Offer, Application, Company, ApplicationStatus, OfferType, CreateCompanyDto, UserRole } from '@/types'
import { StudentProfile } from '@/types/student'
import StatCard from '@/components/shared/StatCard'
import OfferCard from '@/components/shared/OfferCard'
import StudentProfileModal from '@/components/shared/StudentProfileModal'
import ProtectedRoute from '@/components/auth/ProtectedRoute'

const MOCK_OFFERS: Offer[] = [
  { id: 1, title: 'PFE — Deep Learning', company: 'Esprit', type: OfferType.PFE, status: 'open' as any, deadline: '2025-03-15', skills: ['Python'], description: 'CNN model', postedAt: '2025-01-10', applicantCount: 8 },
  { id: 2, title: 'Summer — Web Dev', company: 'Sopra', type: OfferType.SUMMER, status: 'open' as any, deadline: '2025-05-01', skills: ['React'], description: 'Build dashboards', postedAt: '2025-01-12', applicantCount: 12 },
]

const MOCK_APPLICATIONS: Application[] = [
  { id: 1, offerId: 1, offerTitle: 'Deep Learning — Esprit', studentId: 10, studentName: 'Ahmed Ben Salem', status: ApplicationStatus.ACCEPTED, gpa: 3.8, skills: ['Python'], appliedAt: '2025-01-28' },
  { id: 2, offerId: 2, offerTitle: 'Web Dev — Sopra', studentId: 11, studentName: 'Leila Kammoun', status: ApplicationStatus.PENDING, gpa: 3.6, skills: ['React'], appliedAt: '2025-01-30' },
]

const MOCK_COMPANIES: Company[] = [
  { id: 201, name: 'Esprit', sector: 'Technology', offerCount: 8, createdAt: '2024-06-01' },
  { id: 202, name: 'Sopra Steria', sector: 'Consulting', offerCount: 5, createdAt: '2024-06-02' },
]

// Mock student profiles for admin
const MOCK_ADMIN_STUDENTS: StudentProfile[] = [
  {
    id: 10,
    name: 'Ahmed Ben Salem',
    email: 'ahmed.bensalem@enetcom.tn',
    phone: '+216 98 765 432',
    gpa: 3.8,
    major: 'Computer Science',
    year: 5,
    skills: ['Python', 'TensorFlow', 'Machine Learning'],
    bio: 'Passionate about AI and machine learning.',
    cvUrl: '/cvs/ahmed-bensalem-cv.pdf',
    appliedOffers: [1, 3],
    createdAt: '2024-09-01'
  },
  {
    id: 11,
    name: 'Leila Kammoun',
    email: 'leila.kammoun@enetcom.tn',
    phone: '+216 97 654 321',
    gpa: 3.6,
    major: 'Software Engineering',
    year: 4,
    skills: ['React', 'Node.js', 'TypeScript'],
    bio: 'Full-stack developer passionate about web technologies.',
    cvUrl: '/cvs/leila-kammoun-cv.pdf',
    appliedOffers: [2],
    createdAt: '2024-09-15'
  },
  {
    id: 12,
    name: 'Mohamed Dridi',
    email: 'mohamed.dridi@enetcom.tn',
    phone: '+216 99 123 456',
    gpa: 3.9,
    major: 'Data Science',
    year: 5,
    skills: ['Python', 'ML', 'Data Analysis'],
    bio: 'Data science enthusiast with research experience.',
    cvUrl: '/cvs/mohamed-dridi-cv.pdf',
    appliedOffers: [1, 4],
    createdAt: '2024-08-20'
  },
  {
    id: 13,
    name: 'Sara Hamdi',
    email: 'sara.hamdi@enetcom.tn',
    phone: '+216 96 234 567',
    gpa: 3.2,
    major: 'Network Engineering',
    year: 3,
    skills: ['Docker', 'AWS', 'Linux'],
    bio: 'DevOps enthusiast with cloud certifications.',
    cvUrl: '/cvs/sara-hamdi-cv.pdf',
    appliedOffers: [3],
    createdAt: '2024-10-01'
  },
  {
    id: 14,
    name: 'Karim Messaoudi',
    email: 'karim.messaoudi@enetcom.tn',
    phone: '+216 95 345 678',
    gpa: 3.7,
    major: 'Cybersecurity',
    year: 4,
    skills: ['Security', 'Penetration Testing', 'Python'],
    bio: 'Cybersecurity professional with ethical hacking certifications.',
    cvUrl: '/cvs/karim-messaoudi-cv.pdf',
    appliedOffers: [],
    createdAt: '2024-09-10'
  },
]

type Tab = 'offers' | 'applications' | 'companies' | 'students'

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<Tab>('offers')
  const [companies, setCompanies] = useState<Company[]>(MOCK_COMPANIES)
  const [newCompany, setNewCompany] = useState<CreateCompanyDto>({ name: '', sector: 'Technology' })
  const [students, setStudents] = useState<StudentProfile[]>(MOCK_ADMIN_STUDENTS)
  const [selectedStudent, setSelectedStudent] = useState<StudentProfile | null>(null)
  const [showStudentModal, setShowStudentModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const handleAddCompany = () => {
    if (!newCompany.name.trim()) {
      alert('Please enter a company name.')
      return
    }
    const company: Company = {
      id: Date.now(),
      name: newCompany.name,
      sector: newCompany.sector,
      offerCount: 0,
      createdAt: new Date().toISOString()
    }
    setCompanies([...companies, company])
    setNewCompany({ name: '', sector: 'Technology' })
  }

  const handleRemove = (id: number) => {
    setCompanies(companies.filter(c => c.id !== id))
  }

  const handleViewStudent = (student: StudentProfile) => {
    setSelectedStudent(student)
    setShowStudentModal(true)
  }

  const handleDeleteStudent = (id: number) => {
    if (confirm('Are you sure you want to remove this student?')) {
      setStudents(students.filter(s => s.id !== id))
    }
  }

  const filteredStudents = searchQuery
    ? students.filter(s => 
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.major.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : students

  const getStatusBadgeClass = (status: ApplicationStatus) => {
    switch (status) {
      case ApplicationStatus.PENDING:
        return 'bg-[#f1c40f]/20 text-[#f7d94c] border-[#f1c40f]/30'
      case ApplicationStatus.ACCEPTED:
        return 'bg-[#2ecc71]/20 text-[#5dea9e] border-[#2ecc71]/30'
      case ApplicationStatus.REJECTED:
        return 'bg-[#e74c3c]/20 text-[#ff7b7b] border-[#e74c3c]/30'
    }
  }

  const acceptedCount = MOCK_APPLICATIONS.filter(a => a.status === ApplicationStatus.ACCEPTED).length
  const rejectedCount = MOCK_APPLICATIONS.filter(a => a.status === ApplicationStatus.REJECTED).length

  return (
    <ProtectedRoute allowedRole={UserRole.ADMIN}>
      <section className="relative z-10 min-h-screen px-10 pt-28 pb-16">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-9 flex-wrap gap-4">
          <h1 className="font-display text-3xl font-bold text-text-white">
            ⚙️ Administration <span className="text-orange-light">Dashboard</span>
          </h1>

          <div className="flex gap-2 flex-wrap">
            {[
              { label: 'All Offers', value: 'offers' as Tab },
              { label: 'Applications', value: 'applications' as Tab },
              { label: 'Companies', value: 'companies' as Tab },
              { label: 'Manage Students', value: 'students' as Tab },
            ].map(tab => (
              <button
                key={tab.value}
                onClick={() => setActiveTab(tab.value)}
                className={`
                  px-5 py-2 rounded-full font-body text-sm font-semibold tracking-wide transition-all duration-300
                  ${activeTab === tab.value
                    ? 'bg-gradient-to-r from-blue-accent to-orange-main border-transparent text-white'
                    : 'bg-blue-mid/50 border border-blue-accent/20 text-text-dim hover:bg-gradient-to-r hover:from-blue-accent hover:to-orange-main hover:text-white'}
                `}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard value={MOCK_OFFERS.length} label="Total Offers" />
          <StatCard value={MOCK_APPLICATIONS.length} label="Total Applications" />
          <StatCard value={students.length} label="Registered Students" />
          <StatCard value={companies.length} label="Partner Companies" />
        </div>

        {/* Tab Content */}
        {activeTab === 'offers' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {MOCK_OFFERS.map(offer => (
              <OfferCard key={offer.id} offer={offer} showActions={false} />
            ))}
          </div>
        )}

        {activeTab === 'applications' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {MOCK_APPLICATIONS.map(app => (
              <div key={app.id} className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-6 transition-all duration-350 hover:border-orange-main/35 hover:-translate-y-1">
                <span className={`inline-block px-3.5 py-1 rounded-full text-xs font-bold tracking-wide uppercase mb-3.5 border ${getStatusBadgeClass(app.status)}`}>
                  {app.status}
                </span>
                <h3 className="text-lg text-text-white mb-1.5">{app.studentName}</h3>
                <div className="text-orange-light text-sm font-semibold mb-2.5">
                  📋 {app.offerTitle}
                </div>
                <div className="flex gap-4 flex-wrap text-text-dim text-xs font-mono">
                  <span>📅 {app.appliedAt}</span>
                  <span>🎓 GPA: {app.gpa}/4</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'companies' && (
          <>
            {/* Add Company Form */}
            <div className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-7 mb-7">
              <h3 className="font-display text-lg text-text-white mb-4">➕ Add New Company</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4.5 mb-4.5">
                <div>
                  <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                    Company Name
                  </label>
                  <input
                    type="text"
                    value={newCompany.name}
                    onChange={e => setNewCompany({ ...newCompany, name: e.target.value })}
                    placeholder="e.g., Acme Corp"
                    className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
                  />
                </div>
                <div>
                  <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                    Sector
                  </label>
                  <select
                    value={newCompany.sector}
                    onChange={e => setNewCompany({ ...newCompany, sector: e.target.value })}
                    className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
                  >
                    <option>Technology</option>
                    <option>Finance</option>
                    <option>Telecom</option>
                    <option>Consulting</option>
                  </select>
                </div>
              </div>
              <button 
                onClick={handleAddCompany}
                className="bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-base font-bold px-8 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_6px_24px_rgba(232,106,0,0.4)] hover:-translate-y-0.5"
              >
                ➕ Add Company
              </button>
            </div>

            {/* Company List */}
            <div className="flex flex-wrap gap-4">
              {companies.map(company => (
                <div key={company.id} className="flex items-center gap-3 bg-gradient-to-br from-blue-mid/70 to-blue-deep/90 border border-blue-accent/20 rounded-2xl px-5 py-3.5 transition-all duration-300 hover:border-orange-main/30">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl font-bold bg-gradient-to-r from-blue-accent to-orange-main text-white">
                    {company.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-text-white text-sm font-semibold">{company.name}</h4>
                    <p className="text-text-dim text-xs">{company.sector} · {company.offerCount} offers</p>
                  </div>
                  <button
                    onClick={() => handleRemove(company.id)}
                    className="bg-[#e74c3c]/15 border border-[#e74c3c]/30 text-[#ff7b7b] text-xs font-bold px-3 py-1.5 rounded-2xl transition-all duration-300 hover:bg-[#e74c3c]/30 ml-2"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </>
        )}

        {activeTab === 'students' && (
          <>
            {/* Search Bar */}
            <div className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-6 mb-7">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                    Search Students
                  </label>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search by name, email, or major..."
                    className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
                  />
                </div>
                <div className="text-text-dim text-sm pt-7">
                  {filteredStudents.length} student{filteredStudents.length !== 1 ? 's' : ''} found
                </div>
              </div>
            </div>

            {/* Students Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredStudents.map(student => (
                <div 
                  key={student.id}
                  className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-6 transition-all duration-350 hover:border-orange-main/35 hover:-translate-y-1"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold bg-gradient-to-r from-blue-accent to-orange-main text-white flex-shrink-0">
                      {student.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg text-text-white mb-1">{student.name}</h3>
                      <div className="text-orange-light text-sm font-semibold">
                        🎓 {student.major}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-text-dim text-sm">
                      <span>📧</span>
                      <span className="truncate">{student.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-text-dim text-sm">
                      <span>📱</span>
                      <span>{student.phone}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-text-dim text-xs mb-4">
                    <span>GPA: <strong className="text-orange-light">{student.gpa}/4</strong></span>
                    <span>Year {student.year}</span>
                    <span>{student.appliedOffers.length} applications</span>
                  </div>

                  <div className="flex gap-2.5">
                    <button
                      onClick={() => handleViewStudent(student)}
                      className="flex-1 bg-gradient-to-r from-blue-accent to-blue-light text-white font-body text-xs font-bold px-4 py-2 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(46,134,222,0.4)] hover:-translate-y-0.5"
                    >
                      👁️ View Profile
                    </button>
                    <button
                      onClick={() => handleDeleteStudent(student.id)}
                      className="bg-gradient-to-r from-[#e74c3c] to-[#c0392b] text-white font-body text-xs font-bold px-4 py-2 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(231,76,60,0.4)] hover:-translate-y-0.5"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {filteredStudents.length === 0 && (
              <div className="text-center py-12">
                <p className="text-text-dim text-lg">No students found matching your search.</p>
              </div>
            )}
          </>
        )}
      </div>

      {/* Student Profile Modal */}
      {showStudentModal && selectedStudent && (
        <StudentProfileModal
          student={selectedStudent}
          onClose={() => {
            setShowStudentModal(false)
            setSelectedStudent(null)
          }}
        />
      )}
      </section>
    </ProtectedRoute>
  )
}
