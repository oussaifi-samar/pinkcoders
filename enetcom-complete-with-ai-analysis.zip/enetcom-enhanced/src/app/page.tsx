// app/page.tsx
'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import ConceptCards from '@/components/shared/ConceptCards'
import EditionsTimeline from '@/components/shared/EditionsTimeline'
import LoginModal from '@/components/auth/LoginModal'

export default function HomePage() {
  const { user, isAuthenticated } = useAuth()
  const router = useRouter()
  const [showLoginModal, setShowLoginModal] = useState(false)

  useEffect(() => {
    if (isAuthenticated && user) {
      switch (user.role) {
        case 'student':
          router.push('/student')
          break
        case 'company':
          router.push('/company')
          break
        case 'admin':
          router.push('/admin')
          break
      }
    }
  }, [isAuthenticated, user, router])

  // Authenticated users see a brief loading/redirect state
  if (isAuthenticated) {
    return (
      <div className="relative z-10 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin text-4xl mb-4">⏳</div>
          <p className="text-text-white text-lg">Redirecting to dashboard...</p>
        </div>
      </div>
    )
  }

  // Non-authenticated users see the full Home interface
  return (
    <>
      {/* Hero Section */}
      <section className="relative z-10 min-h-screen flex flex-col items-center justify-center text-center px-10 pt-20 pb-16">
        <div className="inline-block bg-gradient-to-r from-orange-main/15 to-blue-accent/15 border border-orange-main/40 text-orange-light px-6 py-2 rounded-full text-xs font-semibold tracking-[3px] uppercase mb-8 animate-fade-in-down">
          🌐 ENET'COM Forum 2025 — Virtual Reality Edition
        </div>

        <h1 className="font-display text-5xl md:text-7xl font-black leading-tight mb-3 opacity-0 animate-fade-in-up [animation-delay:0.2s]">
          <span className="block gradient-text-blue">ENET'COM</span>
          <span className="block gradient-text-orange">FORUM</span>
        </h1>

        <p className="text-xl text-text-dim max-w-2xl mx-auto my-5 leading-relaxed opacity-0 animate-fade-in-up [animation-delay:0.4s]">
          A cutting-edge digital platform connecting students, companies, and
          opportunities in an immersive virtual reality experience. Explore
          internships, build your career, and shape the future — all in 3D.
        </p>

        <div className="flex gap-4 flex-wrap justify-center opacity-0 animate-fade-in-up [animation-delay:0.6s]">
          <button
            onClick={() => setShowLoginModal(true)}
            className="bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-base font-bold px-9 py-3.5 rounded-full cursor-pointer tracking-wider uppercase transition-all duration-350 shadow-[0_4px_30px_rgba(232,106,0,0.35)] hover:translate-y-[-3px] hover:shadow-[0_8px_40px_rgba(232,106,0,0.5)]"
          >
            🎓 Student Portal
          </button>
          <button
            onClick={() => setShowLoginModal(true)}
            className="bg-transparent border-2 border-blue-accent/50 text-blue-glow font-body text-base font-bold px-9 py-3.5 rounded-full cursor-pointer tracking-wider uppercase transition-all duration-350 hover:border-blue-accent hover:shadow-[0_0_25px_rgba(46,134,222,0.3)] hover:translate-y-[-3px]"
          >
            🏢 Company Portal
          </button>
        </div>

        {/* Subtle sign-in hint */}
        <p
          className="mt-10 text-text-dim text-sm opacity-0 animate-fade-in-up [animation-delay:0.9s] cursor-pointer hover:text-orange-light transition-colors"
          onClick={() => setShowLoginModal(true)}
        >
          Already have an account? <span className="text-orange-light font-semibold underline">Sign in →</span>
        </p>
      </section>

      {/* Concept Cards */}
      <ConceptCards />

      {/* Editions Timeline */}
      <EditionsTimeline />

      {/* Login Modal */}
      {showLoginModal && (
        <LoginModal onClose={() => setShowLoginModal(false)} />
      )}
    </>
  )
}
