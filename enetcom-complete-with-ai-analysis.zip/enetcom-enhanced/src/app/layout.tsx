// app/layout.tsx
import type { Metadata } from 'next'
import { Orbitron, Rajdhani, Share_Tech_Mono } from 'next/font/google'
import './globals.css'
import EnhancedThreeDBackground from '@/components/three/EnhancedThreeDBackground'
import Nav from '@/components/shared/Nav'
import Chatbot from '@/components/shared/Chatbot'
import { AuthProvider } from '@/contexts/AuthContext'

const orbitron = Orbitron({ 
  subsets: ['latin'],
  variable: '--font-display',
  weight: ['400', '700', '900']
})

const rajdhani = Rajdhani({ 
  subsets: ['latin'],
  variable: '--font-body',
  weight: ['300', '400', '500', '600', '700']
})

const shareTechMono = Share_Tech_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['400']
})

export const metadata: Metadata = {
  title: "ENET'COM Forum — Virtual Reality Edition",
  description: 'A cutting-edge digital platform connecting students, companies, and opportunities in an immersive VR experience.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${orbitron.variable} ${rajdhani.variable} ${shareTechMono.variable}`}>
      <head>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js" defer></script>
      </head>
      <body>
        <AuthProvider>
          {/* Layer 0: Enhanced 3D background with particles */}
          <EnhancedThreeDBackground />
          
          {/* Layer 1: Navigation */}
          <Nav />
          
          {/* Layer 2: Page content */}
          <main className="relative z-10">
            {children}
          </main>

          {/* Layer 3: Floating Chatbot */}
          <Chatbot />
        </AuthProvider>
      </body>
    </html>
  )
}
