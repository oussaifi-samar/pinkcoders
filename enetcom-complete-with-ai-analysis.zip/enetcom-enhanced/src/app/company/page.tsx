// app/company/page.tsx
'use client'

import { useState } from 'react'
import { Application, ApplicationStatus, CreateOfferDto, OfferType, UserRole } from '@/types'
import { StudentProfile } from '@/types/student'
import StatCard from '@/components/shared/StatCard'
import StudentProfileModal from '@/components/shared/StudentProfileModal'
import ProtectedRoute from '@/components/auth/ProtectedRoute'

const MOCK_APPLICATIONS: Application[] = [
  { id: 1, offerId: 101, offerTitle: 'PFE — ML Pipeline', studentId: 10, studentName: 'Ahmed Ben Salem', status: ApplicationStatus.PENDING, gpa: 3.8, skills: ['Python', 'TensorFlow'], appliedAt: '2025-01-28' },
  { id: 2, offerId: 102, offerTitle: 'Summer — Backend Developer', studentId: 11, studentName: 'Leila Kammoun', status: ApplicationStatus.PENDING, gpa: 3.6, skills: ['React', 'Node.js'], appliedAt: '2025-01-30' },
  { id: 3, offerId: 101, offerTitle: 'PFE — ML Pipeline', studentId: 12, studentName: 'Mohamed Dridi', status: ApplicationStatus.ACCEPTED, gpa: 3.9, skills: ['Python', 'ML'], appliedAt: '2025-01-25' },
  { id: 4, offerId: 103, offerTitle: 'Senior DevOps Engineer', studentId: 13, studentName: 'Sara Hamdi', status: ApplicationStatus.REJECTED, gpa: 3.2, skills: ['Docker', 'AWS'], appliedAt: '2025-01-22' },
]

// Mock student profiles
const MOCK_STUDENT_PROFILES: StudentProfile[] = [
  {
    id: 10,
    name: 'Ahmed Ben Salem',
    email: 'ahmed.bensalem@enetcom.tn',
    phone: '+216 98 765 432',
    gpa: 3.8,
    major: 'Computer Science',
    year: 5,
    skills: ['Python', 'TensorFlow', 'Machine Learning', 'Deep Learning', 'Computer Vision'],
    bio: 'Passionate about AI and machine learning with hands-on experience in deep learning projects. Completed several academic projects in computer vision and natural language processing.',
    cvUrl: '/cvs/ahmed-bensalem-cv.pdf',
    appliedOffers: [101, 105],
    createdAt: '2024-09-01'
  },
  {
    id: 11,
    name: 'Leila Kammoun',
    email: 'leila.kammoun@enetcom.tn',
    phone: '+216 97 654 321',
    gpa: 3.6,
    major: 'Software Engineering',
    year: 4,
    skills: ['React', 'Node.js', 'Express', 'MongoDB', 'REST APIs', 'TypeScript'],
    bio: 'Full-stack developer with a focus on modern web technologies. Experienced in building scalable web applications using React and Node.js. Strong problem-solving skills and eager to learn new technologies.',
    cvUrl: '/cvs/leila-kammoun-cv.pdf',
    appliedOffers: [102],
    createdAt: '2024-09-15'
  },
  {
    id: 12,
    name: 'Mohamed Dridi',
    email: 'mohamed.dridi@enetcom.tn',
    phone: '+216 99 123 456',
    gpa: 3.9,
    major: 'Data Science',
    year: 5,
    skills: ['Python', 'ML', 'Data Analysis', 'PyTorch', 'Scikit-learn', 'SQL'],
    bio: 'Data science enthusiast with strong analytical skills. Published research paper on predictive modeling. Experienced in working with large datasets and building ML pipelines.',
    cvUrl: '/cvs/mohamed-dridi-cv.pdf',
    appliedOffers: [101, 104, 106],
    createdAt: '2024-08-20'
  },
  {
    id: 13,
    name: 'Sara Hamdi',
    email: 'sara.hamdi@enetcom.tn',
    phone: '+216 96 234 567',
    gpa: 3.2,
    major: 'Network Engineering',
    year: 3,
    skills: ['Docker', 'AWS', 'Linux', 'CI/CD', 'Jenkins', 'Git'],
    bio: 'DevOps enthusiast with practical experience in containerization and cloud services. Completed AWS certification and worked on several automation projects.',
    cvUrl: '/cvs/sara-hamdi-cv.pdf',
    appliedOffers: [103],
    createdAt: '2024-10-01'
  },
]

export default function CompanyPage() {
  const [applications, setApplications] = useState<Application[]>(MOCK_APPLICATIONS)
  const [formData, setFormData] = useState<CreateOfferDto>({
    title: '',
    type: OfferType.PFE,
    deadline: '',
    description: ''
  })
  const [selectedStudent, setSelectedStudent] = useState<StudentProfile | null>(null)
  const [showStudentModal, setShowStudentModal] = useState(false)
  const [activeTab, setActiveTab] = useState<'applications' | 'students'>('applications')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.title.trim()) {
      alert('Please enter an offer title.')
      return
    }
    alert('✅ Offer published successfully!')
    setFormData({ title: '', type: OfferType.PFE, deadline: '', description: '' })
  }

  const handleAction = (id: number, status: ApplicationStatus) => {
    setApplications(prev => 
      prev.map(app => app.id === id ? { ...app, status } : app)
    )
  }

  const handleViewProfile = (studentId: number) => {
    const student = MOCK_STUDENT_PROFILES.find(s => s.id === studentId)
    if (student) {
      setSelectedStudent(student)
      setShowStudentModal(true)
    }
  }

  const handleAcceptFromProfile = () => {
    if (selectedStudent) {
      const application = applications.find(app => app.studentId === selectedStudent.id && app.status === ApplicationStatus.PENDING)
      if (application) {
        handleAction(application.id, ApplicationStatus.ACCEPTED)
      }
    }
  }

  const handleRejectFromProfile = () => {
    if (selectedStudent) {
      const application = applications.find(app => app.studentId === selectedStudent.id && app.status === ApplicationStatus.PENDING)
      if (application) {
        handleAction(application.id, ApplicationStatus.REJECTED)
      }
    }
  }

  const getStatusBadgeClass = (status: ApplicationStatus) => {
    switch (status) {
      case ApplicationStatus.PENDING:
        return 'bg-[#f1c40f]/20 text-[#f7d94c] border-[#f1c40f]/30'
      case ApplicationStatus.ACCEPTED:
        return 'bg-[#2ecc71]/20 text-[#5dea9e] border-[#2ecc71]/30'
      case ApplicationStatus.REJECTED:
        return 'bg-[#e74c3c]/20 text-[#ff7b7b] border-[#e74c3c]/30'
    }
  }

  const acceptedCount = applications.filter(a => a.status === ApplicationStatus.ACCEPTED).length
  const pendingCount = applications.filter(a => a.status === ApplicationStatus.PENDING).length

  return (
    <ProtectedRoute allowedRole={UserRole.COMPANY}>
      <section className="relative z-10 min-h-screen px-10 pt-28 pb-16">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-9 flex-wrap gap-4">
          <h1 className="font-display text-3xl font-bold text-text-white">
            🏢 Company <span className="text-orange-light">Dashboard</span>
          </h1>

          <div className="flex gap-2 flex-wrap">
            {[
              { label: 'Applications', value: 'applications' as const },
              { label: 'Student Profiles', value: 'students' as const },
            ].map(tab => (
              <button
                key={tab.value}
                onClick={() => setActiveTab(tab.value)}
                className={`
                  px-5 py-2 rounded-full font-body text-sm font-semibold tracking-wide transition-all duration-300
                  ${activeTab === tab.value
                    ? 'bg-gradient-to-r from-blue-accent to-orange-main border-transparent text-white'
                    : 'bg-blue-mid/50 border border-blue-accent/20 text-text-dim hover:bg-gradient-to-r hover:from-blue-accent hover:to-orange-main hover:text-white'}
                `}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard value={12} label="Offers Posted" />
          <StatCard value={applications.length} label="Applications" />
          <StatCard value={acceptedCount} label="Accepted" />
          <StatCard value={pendingCount} label="Pending Review" />
        </div>

        {/* Post Offer Form */}
        <div className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-8 mb-8">
          <h3 className="font-display text-lg text-text-white mb-4.5">📝 Post a New Offer</h3>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5 mb-4.5">
              <div>
                <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                  Offer Title
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., PFE — ML Engineer"
                  className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
                />
              </div>
              <div>
                <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                  Offer Type
                </label>
                <select
                  value={formData.type}
                  onChange={e => setFormData({ ...formData, type: e.target.value as OfferType })}
                  className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
                >
                  <option value={OfferType.PFE}>PFE Project</option>
                  <option value={OfferType.SUMMER}>Summer Internship</option>
                  <option value={OfferType.JOB}>Full-Time Job</option>
                </select>
              </div>
              <div>
                <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                  Deadline
                </label>
                <input
                  type="date"
                  value={formData.deadline}
                  onChange={e => setFormData({ ...formData, deadline: e.target.value })}
                  className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
                />
              </div>
            </div>
            <div className="mb-4.5">
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe the opportunity…"
                rows={3}
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)] resize-vertical"
              />
            </div>
            <button 
              type="submit"
              className="bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-base font-bold px-8 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_6px_24px_rgba(232,106,0,0.4)] hover:-translate-y-0.5"
            >
              📤 Publish Offer
            </button>
          </form>
        </div>

        {/* Applications */}
        {activeTab === 'applications' && (
          <>
            <div className="mb-5.5">
              <h2 className="font-display text-xl text-text-white mb-5.5">📋 Applications to Review</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {applications.map(app => (
                <div key={app.id} className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-6 transition-all duration-350 hover:border-orange-main/35 hover:-translate-y-1">
                  <span className={`inline-block px-3.5 py-1 rounded-full text-xs font-bold tracking-wide uppercase mb-3.5 border ${getStatusBadgeClass(app.status)}`}>
                    {app.status}
                  </span>
                  <h3 className="text-lg text-text-white mb-1.5">{app.offerTitle}</h3>
                  <div className="text-orange-light text-sm font-semibold mb-2.5">
                    👤 {app.studentName}
                  </div>
                  <p className="text-text-dim text-sm mb-2.5">
                    GPA: <strong className="text-orange-light">{app.gpa}/4</strong>
                    &nbsp;|&nbsp;
                    Skills: {app.skills.join(', ')}
                  </p>
                  <div className="text-text-dim text-xs font-mono mb-4">
                    📅 Applied: {app.appliedAt}
                  </div>

                  <div className="flex gap-2.5 flex-wrap">
                    <button
                      onClick={() => handleViewProfile(app.studentId)}
                      className="bg-gradient-to-r from-blue-accent to-blue-light text-white font-body text-xs font-bold px-4.5 py-1.5 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(46,134,222,0.4)] hover:-translate-y-0.5"
                    >
                      👁️ View Profile
                    </button>
                    {app.status === ApplicationStatus.PENDING && (
                      <>
                        <button
                          onClick={() => handleAction(app.id, ApplicationStatus.ACCEPTED)}
                          className="bg-gradient-to-r from-[#27ae60] to-[#219a52] text-white font-body text-xs font-bold px-4.5 py-1.5 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(39,174,96,0.4)] hover:-translate-y-0.5"
                        >
                          ✓ Accept
                        </button>
                        <button
                          onClick={() => handleAction(app.id, ApplicationStatus.REJECTED)}
                          className="bg-gradient-to-r from-[#e74c3c] to-[#c0392b] text-white font-body text-xs font-bold px-4.5 py-1.5 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(231,76,60,0.4)] hover:-translate-y-0.5"
                        >
                          ✗ Reject
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Student Profiles */}
        {activeTab === 'students' && (
          <>
            <div className="mb-5.5">
              <h2 className="font-display text-xl text-text-white mb-5.5">👥 Student Profiles</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {MOCK_STUDENT_PROFILES.map(student => (
                <div 
                  key={student.id} 
                  onClick={() => handleViewProfile(student.id)}
                  className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-6 transition-all duration-350 hover:border-orange-main/35 hover:-translate-y-1 cursor-pointer"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold bg-gradient-to-r from-blue-accent to-orange-main text-white flex-shrink-0">
                      {student.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg text-text-white mb-1">{student.name}</h3>
                      <div className="text-orange-light text-sm font-semibold">
                        🎓 {student.major}
                      </div>
                    </div>
                  </div>

                  <p className="text-text-dim text-sm mb-3 line-clamp-2">
                    {student.bio}
                  </p>

                  <div className="flex items-center justify-between text-text-dim text-xs mb-3">
                    <span>GPA: <strong className="text-orange-light">{student.gpa}/4</strong></span>
                    <span>Year {student.year}</span>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {student.skills.slice(0, 3).map((skill, index) => (
                      <span
                        key={index}
                        className="bg-blue-accent/20 border border-blue-accent/30 text-text-white px-2.5 py-1 rounded-full text-xs"
                      >
                        {skill}
                      </span>
                    ))}
                    {student.skills.length > 3 && (
                      <span className="bg-blue-accent/20 border border-blue-accent/30 text-text-white px-2.5 py-1 rounded-full text-xs">
                        +{student.skills.length - 3}
                      </span>
                    )}
                  </div>

                  <button className="w-full bg-gradient-to-r from-blue-accent to-blue-light text-white font-body text-xs font-bold px-4 py-2 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(46,134,222,0.4)]">
                    View Full Profile
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Student Profile Modal */}
      {showStudentModal && selectedStudent && (
        <StudentProfileModal
          student={selectedStudent}
          onClose={() => {
            setShowStudentModal(false)
            setSelectedStudent(null)
          }}
          onAccept={handleAcceptFromProfile}
          onReject={handleRejectFromProfile}
        />
      )}
      </section>
    </ProtectedRoute>
  )
}
