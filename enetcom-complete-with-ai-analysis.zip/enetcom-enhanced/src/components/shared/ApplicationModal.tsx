// components/shared/ApplicationModal.tsx
'use client'

import { useState } from 'react'
import { Offer } from '@/types'
import { ApplicationFormData } from '@/types/student'

interface ApplicationModalProps {
  offer: Offer
  onClose: () => void
  onSubmit: (data: ApplicationFormData) => void
}

export default function ApplicationModal({ offer, onClose, onSubmit }: ApplicationModalProps) {
  const [formData, setFormData] = useState<ApplicationFormData>({
    studentName: '',
    studentEmail: '',
    studentPhone: '',
    gpa: 0,
    major: '',
    year: 1,
    coverLetter: '',
  })
  const [cvFileName, setCvFileName] = useState<string>('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.studentName.trim() || !formData.studentEmail.trim()) {
      alert('Please fill in all required fields.')
      return
    }

    onSubmit(formData)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setCvFileName(file.name)
      setFormData({ ...formData, cvFile: file })
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm px-4">
      <div className="bg-gradient-to-br from-blue-mid/95 to-blue-deep/95 border border-blue-accent/20 rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-bold text-text-white">
            Apply for <span className="text-orange-light">{offer.title}</span>
          </h2>
          <button
            onClick={onClose}
            className="text-text-dim hover:text-text-white transition-colors text-2xl"
          >
            ✕
          </button>
        </div>

        <div className="mb-6 p-4 bg-blue-mid/40 border border-blue-accent/15 rounded-xl">
          <div className="text-orange-light text-sm font-semibold mb-2">
            🏢 {offer.company}
          </div>
          <p className="text-text-dim text-sm">{offer.description}</p>
          <div className="flex gap-4 flex-wrap text-text-dim text-xs font-mono mt-3">
            <span>📅 Deadline: {offer.deadline}</span>
            <span>🔧 {offer.skills.join(', ')}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Full Name *
              </label>
              <input
                type="text"
                value={formData.studentName}
                onChange={e => setFormData({ ...formData, studentName: e.target.value })}
                placeholder="e.g., Ahmed Ben Salem"
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              />
            </div>

            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Email *
              </label>
              <input
                type="email"
                value={formData.studentEmail}
                onChange={e => setFormData({ ...formData, studentEmail: e.target.value })}
                placeholder="e.g., ahmed@example.com"
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              />
            </div>

            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Phone Number *
              </label>
              <input
                type="tel"
                value={formData.studentPhone}
                onChange={e => setFormData({ ...formData, studentPhone: e.target.value })}
                placeholder="e.g., +216 XX XXX XXX"
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              />
            </div>

            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                GPA *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                max="4"
                value={formData.gpa}
                onChange={e => setFormData({ ...formData, gpa: parseFloat(e.target.value) })}
                placeholder="e.g., 3.5"
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              />
            </div>

            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Major *
              </label>
              <input
                type="text"
                value={formData.major}
                onChange={e => setFormData({ ...formData, major: e.target.value })}
                placeholder="e.g., Computer Science"
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              />
            </div>

            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Current Year *
              </label>
              <select
                value={formData.year}
                onChange={e => setFormData({ ...formData, year: parseInt(e.target.value) })}
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              >
                <option value={1}>1st Year</option>
                <option value={2}>2nd Year</option>
                <option value={3}>3rd Year</option>
                <option value={4}>4th Year</option>
                <option value={5}>5th Year</option>
              </select>
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
              Cover Letter *
            </label>
            <textarea
              value={formData.coverLetter}
              onChange={e => setFormData({ ...formData, coverLetter: e.target.value })}
              placeholder="Explain why you're a great fit for this position..."
              rows={5}
              required
              className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)] resize-vertical"
            />
          </div>

          <div className="mb-6">
            <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
              Upload CV (PDF) *
            </label>
            <div className="relative">
              <input
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleFileChange}
                required
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div className="bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 hover:border-orange-main cursor-pointer flex items-center justify-between">
                <span className={cvFileName ? 'text-text-white' : 'text-text-dim'}>
                  {cvFileName || 'Click to upload CV'}
                </span>
                <span className="text-orange-light">📄</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3 justify-end">
            <button
              type="button"
              onClick={onClose}
              className="bg-blue-mid/60 border border-blue-accent/20 text-text-white font-body text-sm font-semibold px-6 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:bg-blue-mid/80"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-sm font-bold px-6 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_6px_24px_rgba(232,106,0,0.4)] hover:-translate-y-0.5"
            >
              📤 Submit Application
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
