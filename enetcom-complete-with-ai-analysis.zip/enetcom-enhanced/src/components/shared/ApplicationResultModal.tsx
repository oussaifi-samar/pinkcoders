// src/components/shared/ApplicationResultModal.tsx
'use client'

import { useEffect, useState } from 'react'
import { AnalysisResult } from '@/lib/services/applicationAnalyzer'
import { Offer } from '@/types'

interface ApplicationResultModalProps {
  result: AnalysisResult
  offer: Offer
  onClose: () => void
}

export default function ApplicationResultModal({ result, offer, onClose }: ApplicationResultModalProps) {
  const [animatedPercentage, setAnimatedPercentage] = useState(0)
  const [showDetails, setShowDetails] = useState(false)

  // Animation du pourcentage d'acceptation
  useEffect(() => {
    const duration = 2000 // 2 secondes
    const steps = 50
    const increment = result.acceptanceProbability / steps
    let current = 0

    const timer = setInterval(() => {
      current += increment
      if (current >= result.acceptanceProbability) {
        setAnimatedPercentage(result.acceptanceProbability)
        clearInterval(timer)
        setTimeout(() => setShowDetails(true), 300)
      } else {
        setAnimatedPercentage(Math.floor(current))
      }
    }, duration / steps)

    return () => clearInterval(timer)
  }, [result.acceptanceProbability])

  // Couleur en fonction du score
  const getScoreColor = (score: number) => {
    if (score >= 75) return 'from-green-500 to-emerald-600'
    if (score >= 60) return 'from-blue-500 to-cyan-600'
    if (score >= 40) return 'from-yellow-500 to-orange-500'
    return 'from-red-500 to-pink-600'
  }

  const getRecommendationText = () => {
    switch (result.recommendation) {
      case 'highly_recommended':
        return { text: 'Fortement Recommandé', icon: '🌟', color: 'text-green-400' }
      case 'recommended':
        return { text: 'Recommandé', icon: '✅', color: 'text-blue-400' }
      case 'possible':
        return { text: 'Possible', icon: '⚠️', color: 'text-yellow-400' }
      case 'not_recommended':
        return { text: 'À Améliorer', icon: '📈', color: 'text-orange-400' }
    }
  }

  const recommendation = getRecommendationText()

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md px-4 animate-fade-in">
      <div className="bg-gradient-to-br from-blue-mid/98 to-blue-deep/98 border border-blue-accent/30 rounded-3xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-[0_30px_80px_rgba(0,0,0,0.6)]">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-block px-6 py-2 rounded-full bg-gradient-to-r from-orange-main/20 to-blue-accent/20 border border-orange-main/30 mb-4">
            <span className="text-orange-light font-display font-bold text-sm tracking-wider uppercase">
              🤖 Analyse IA Complétée
            </span>
          </div>
          <h2 className="font-display text-3xl font-black text-text-white mb-2">
            Résultat de Candidature
          </h2>
          <p className="text-text-dim text-sm">
            {offer.title} • {offer.company}
          </p>
        </div>

        {/* Circular Progress - Main Score */}
        <div className="flex justify-center mb-8">
          <div className="relative w-64 h-64">
            {/* Background Circle */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="128"
                cy="128"
                r="110"
                stroke="rgba(46, 134, 222, 0.2)"
                strokeWidth="20"
                fill="none"
              />
              {/* Progress Circle */}
              <circle
                cx="128"
                cy="128"
                r="110"
                stroke="url(#gradient)"
                strokeWidth="20"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 110}`}
                strokeDashoffset={`${2 * Math.PI * 110 * (1 - animatedPercentage / 100)}`}
                strokeLinecap="round"
                className="transition-all duration-300"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" className="text-orange-main" stopColor="currentColor" />
                  <stop offset="100%" className="text-blue-accent" stopColor="currentColor" />
                </linearGradient>
              </defs>
            </svg>

            {/* Center Text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="font-display text-6xl font-black gradient-text-mixed">
                {animatedPercentage}%
              </div>
              <div className={`font-body text-sm font-semibold mt-2 ${recommendation.color}`}>
                {recommendation.icon} {recommendation.text}
              </div>
            </div>
          </div>
        </div>

        {/* Details Section */}
        {showDetails && (
          <div className="space-y-6 animate-fade-in-up">
            
            {/* Score Breakdown */}
            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-2xl p-6">
              <h3 className="font-display text-lg font-bold text-text-white mb-4 flex items-center gap-2">
                📊 Analyse Détaillée
              </h3>
              
              <div className="space-y-3">
                {Object.entries(result.breakdown).map(([key, value]) => {
                  const labels: Record<string, string> = {
                    gpa: '🎓 Moyenne Académique',
                    experience: '💼 Expérience',
                    skills: '🔧 Compétences Techniques',
                    coverLetter: '✍️ Lettre de Motivation'
                  }

                  return (
                    <div key={key}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-text-dim">{labels[key]}</span>
                        <span className="text-text-white font-semibold">{value}%</span>
                      </div>
                      <div className="h-2 bg-blue-deep/50 rounded-full overflow-hidden">
                        <div
                          className={`h-full bg-gradient-to-r ${getScoreColor(value)} transition-all duration-1000`}
                          style={{ width: `${value}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Strengths */}
            {result.strengths.length > 0 && (
              <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-6">
                <h3 className="font-display text-lg font-bold text-green-400 mb-3 flex items-center gap-2">
                  ✨ Vos Points Forts
                </h3>
                <ul className="space-y-2">
                  {result.strengths.map((strength, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-text-white">
                      <span className="text-green-400 mt-0.5">✓</span>
                      <span>{strength}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Improvements */}
            {result.improvements.length > 0 && (
              <div className="bg-orange-500/10 border border-orange-500/30 rounded-2xl p-6">
                <h3 className="font-display text-lg font-bold text-orange-400 mb-3 flex items-center gap-2">
                  💡 Suggestions d'Amélioration
                </h3>
                <ul className="space-y-2">
                  {result.improvements.map((improvement, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-text-white">
                      <span className="text-orange-400 mt-0.5">→</span>
                      <span>{improvement}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Next Steps */}
            <div className="bg-gradient-to-r from-blue-accent/20 to-orange-main/20 border border-blue-accent/30 rounded-2xl p-6">
              <h3 className="font-display text-lg font-bold text-text-white mb-3 flex items-center gap-2">
                🚀 Prochaines Étapes
              </h3>
              <div className="space-y-2 text-sm text-text-dim">
                <p>✓ Votre candidature a été enregistrée avec succès</p>
                <p>✓ L'entreprise recevra une notification sous 24h</p>
                <p>✓ Vous serez contacté(e) par email pour la suite</p>
                <p className="text-orange-light font-semibold mt-3">
                  💼 Continuez à postuler pour maximiser vos chances !
                </p>
              </div>
            </div>

          </div>
        )}

        {/* Close Button */}
        <div className="flex justify-center mt-8">
          <button
            onClick={onClose}
            className="bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-base font-bold px-12 py-4 rounded-full uppercase tracking-wider transition-all duration-300 hover:shadow-[0_8px_30px_rgba(232,106,0,0.5)] hover:-translate-y-1"
          >
            Continuer à Explorer
          </button>
        </div>

      </div>
    </div>
  )
}
