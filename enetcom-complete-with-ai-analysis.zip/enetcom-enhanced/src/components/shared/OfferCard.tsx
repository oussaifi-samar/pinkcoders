// components/shared/OfferCard.tsx
import { Offer, OfferType } from '@/types'

interface OfferCardProps {
  offer: Offer
  onApply?: () => void
  onDetails?: () => void
  showActions?: boolean
}

export default function OfferCard({ offer, onApply, onDetails, showActions = true }: OfferCardProps) {
  const getTypeBadgeClass = (type: OfferType) => {
    switch (type) {
      case OfferType.PFE:
        return 'bg-blue-accent/20 text-blue-glow border-blue-accent/30'
      case OfferType.SUMMER:
        return 'bg-orange-main/20 text-orange-light border-orange-main/30'
      case OfferType.JOB:
        return 'bg-blue-glow/15 text-[#7bc4ff] border-blue-glow/25'
    }
  }

  const getTypeLabel = (type: OfferType) => {
    switch (type) {
      case OfferType.PFE:
        return 'PFE Project'
      case OfferType.SUMMER:
        return 'Summer Internship'
      case OfferType.JOB:
        return 'Full-Time Job'
    }
  }

  return (
    <div className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-6 transition-all duration-350 hover:border-orange-main/35 hover:-translate-y-1 hover:shadow-[0_12px_40px_rgba(0,0,0,0.3)]">
      <span className={`inline-block px-3.5 py-1 rounded-full text-xs font-bold tracking-wide uppercase mb-3.5 border ${getTypeBadgeClass(offer.type)}`}>
        {getTypeLabel(offer.type)}
      </span>

      <h3 className="text-lg text-text-white mb-1.5">{offer.title}</h3>
      <div className="text-orange-light text-sm font-semibold mb-2.5">
        🏢 {offer.company}
      </div>
      <p className="text-text-dim text-sm leading-relaxed mb-3.5">
        {offer.description}
      </p>

      <div className="flex gap-4 flex-wrap text-text-dim text-xs font-mono mb-4">
        <span>📅 Deadline: {offer.deadline}</span>
        <span>🔧 {offer.skills.join(', ')}</span>
        {offer.applicantCount !== undefined && (
          <span>📊 {offer.applicantCount} applications</span>
        )}
      </div>

      {showActions && (
        <div className="flex gap-2.5">
          <button 
            onClick={onApply}
            className="bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-xs font-bold px-4.5 py-1.5 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(232,106,0,0.4)] hover:-translate-y-0.5"
          >
            Apply Now
          </button>
          <button 
            onClick={onDetails}
            className="bg-gradient-to-r from-blue-accent to-blue-light text-white font-body text-xs font-bold px-4.5 py-1.5 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(46,134,222,0.4)] hover:-translate-y-0.5"
          >
            Details
          </button>
        </div>
      )}
    </div>
  )
}
