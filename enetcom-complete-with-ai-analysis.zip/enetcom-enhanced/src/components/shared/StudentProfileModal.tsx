// components/shared/StudentProfileModal.tsx
'use client'

import { StudentProfile } from '@/types/student'

interface StudentProfileModalProps {
  student: StudentProfile
  onClose: () => void
  onAccept?: () => void
  onReject?: () => void
}

export default function StudentProfileModal({ 
  student, 
  onClose, 
  onAccept, 
  onReject 
}: StudentProfileModalProps) {
  
  const getYearLabel = (year: number) => {
    const labels = ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year']
    return labels[year - 1] || `Year ${year}`
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm px-4">
      <div className="bg-gradient-to-br from-blue-mid/95 to-blue-deep/95 border border-blue-accent/20 rounded-2xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-bold text-text-white">
            Student <span className="text-orange-light">Profile</span>
          </h2>
          <button
            onClick={onClose}
            className="text-text-dim hover:text-text-white transition-colors text-2xl"
          >
            ✕
          </button>
        </div>

        <div className="space-y-6">
          {/* Profile Header */}
          <div className="flex items-start gap-6">
            <div className="w-24 h-24 rounded-2xl flex items-center justify-center text-4xl font-bold bg-gradient-to-r from-blue-accent to-orange-main text-white flex-shrink-0">
              {student.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
            <div className="flex-1">
              <h3 className="text-2xl font-display text-text-white mb-2">{student.name}</h3>
              <div className="space-y-1 text-text-dim">
                <div className="flex items-center gap-2">
                  <span>📧</span>
                  <a href={`mailto:${student.email}`} className="text-orange-light hover:underline">
                    {student.email}
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <span>📱</span>
                  <span>{student.phone}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Academic Information */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-4">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                GPA
              </div>
              <div className="text-orange-light text-2xl font-bold">
                {student.gpa.toFixed(2)}/4.0
              </div>
            </div>

            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-4">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Major
              </div>
              <div className="text-text-white text-lg font-semibold">
                🎓 {student.major}
              </div>
            </div>

            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-4">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Academic Year
              </div>
              <div className="text-text-white text-lg font-semibold">
                📚 {getYearLabel(student.year)}
              </div>
            </div>
          </div>

          {/* Bio */}
          {student.bio && (
            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-5">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-3">
                About
              </div>
              <p className="text-text-white leading-relaxed">
                {student.bio}
              </p>
            </div>
          )}

          {/* Skills */}
          <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-5">
            <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-3">
              Technical Skills
            </div>
            <div className="flex flex-wrap gap-2">
              {student.skills.map((skill, index) => (
                <span
                  key={index}
                  className="bg-gradient-to-r from-blue-accent/20 to-orange-main/20 border border-blue-accent/30 text-text-white px-4 py-2 rounded-full text-sm font-semibold"
                >
                  🔧 {skill}
                </span>
              ))}
            </div>
          </div>

          {/* CV Download */}
          {student.cvUrl && (
            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-5">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-3">
                Resume / CV
              </div>
              <a
                href={student.cvUrl}
                download
                className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-accent to-blue-light text-white font-body text-sm font-bold px-6 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(46,134,222,0.4)] hover:-translate-y-0.5"
              >
                📄 Download CV
              </a>
            </div>
          )}

          {/* Statistics */}
          <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-5">
            <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-3">
              Application History
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-text-dim text-xs mb-1">Total Applications</div>
                <div className="text-text-white text-xl font-bold">
                  {student.appliedOffers.length}
                </div>
              </div>
              <div>
                <div className="text-text-dim text-xs mb-1">Member Since</div>
                <div className="text-text-white text-xl font-bold">
                  {new Date(student.createdAt).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short' 
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 justify-end pt-4">
            <button
              onClick={onClose}
              className="bg-blue-mid/60 border border-blue-accent/20 text-text-white font-body text-sm font-semibold px-6 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:bg-blue-mid/80"
            >
              Close
            </button>
            {onReject && (
              <button
                onClick={() => {
                  onReject()
                  onClose()
                }}
                className="bg-gradient-to-r from-[#e74c3c] to-[#c0392b] text-white font-body text-sm font-bold px-6 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(231,76,60,0.4)] hover:-translate-y-0.5"
              >
                ✗ Reject
              </button>
            )}
            {onAccept && (
              <button
                onClick={() => {
                  onAccept()
                  onClose()
                }}
                className="bg-gradient-to-r from-[#27ae60] to-[#219a52] text-white font-body text-sm font-bold px-6 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_4px_18px_rgba(39,174,96,0.4)] hover:-translate-y-0.5"
              >
                ✓ Accept
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
