// components/shared/Nav.tsx
'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'

export default function Nav() {
  const pathname = usePathname()
  const { user, logout, isAuthenticated } = useAuth()

  const isActive = (path: string) => {
    if (path === '/') return pathname === '/'
    return pathname.startsWith(path)
  }

  const navBtnClass = (path: string) => `
    bg-transparent border border-blue-accent/30 text-text-white 
    font-body text-sm font-semibold px-5 py-2 rounded-full 
    cursor-pointer tracking-wide uppercase transition-all duration-300
    hover:bg-gradient-to-r hover:from-blue-accent hover:to-orange-main 
    hover:border-transparent hover:shadow-[0_0_20px_rgba(46,134,222,0.4)]
    ${isActive(path) ? 'bg-gradient-to-r from-blue-accent to-orange-main border-transparent shadow-[0_0_20px_rgba(46,134,222,0.4)]' : ''}
  `

  return (
    <nav className="fixed top-0 left-0 w-full z-[1000] px-5 md:px-10 py-3 md:py-4 flex items-center justify-between bg-blue-deep/70 backdrop-blur-xl border-b border-blue-accent/20 transition-all duration-400">
      <div className="font-display text-xl md:text-2xl font-black gradient-text-mixed tracking-wider">
        ENET'COM
      </div>
      
      <div className="flex gap-2 items-center">
        {/* Home — toujours visible */}
        <Link href="/" className={navBtnClass('/')}>
          🏠 <span className="hidden sm:inline">Home</span>
        </Link>

        {/* Dashboard, user info & logout — uniquement si authentifié */}
        {isAuthenticated && (
          <>
            {user?.role === 'student' && (
              <Link href="/student" className={navBtnClass('/student')}>
                🎓 <span className="hidden sm:inline">Dashboard</span>
              </Link>
            )}
            {user?.role === 'company' && (
              <Link href="/company" className={navBtnClass('/company')}>
                🏢 <span className="hidden sm:inline">Dashboard</span>
              </Link>
            )}
            {user?.role === 'admin' && (
              <Link href="/admin" className={navBtnClass('/admin')}>
                ⚙️ <span className="hidden sm:inline">Dashboard</span>
              </Link>
            )}

            {/* User info */}
            <div className="hidden md:flex items-center gap-2 bg-blue-mid/40 border border-blue-accent/20 px-4 py-2 rounded-full">
              <span className="text-orange-light text-xs font-semibold">👤</span>
              <span className="text-text-white text-sm font-semibold">{user?.name}</span>
            </div>

            {/* Logout button */}
            <button
              onClick={logout}
              className="bg-gradient-to-r from-[#e74c3c] to-[#c0392b] border-transparent text-white font-body text-sm font-semibold px-5 py-2 rounded-full cursor-pointer tracking-wide uppercase transition-all duration-300 hover:shadow-[0_0_20px_rgba(231,76,60,0.4)]"
            >
              🚪 <span className="hidden sm:inline">Logout</span>
            </button>
          </>
        )}
      </div>
    </nav>
  )
}
