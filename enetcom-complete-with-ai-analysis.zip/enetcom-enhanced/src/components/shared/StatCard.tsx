// components/shared/StatCard.tsx
interface StatCardProps {
  value: number | string
  label: string
}

export default function StatCard({ value, label }: StatCardProps) {
  return (
    <div className="bg-gradient-to-br from-blue-mid/70 to-blue-deep/90 border border-blue-accent/15 rounded-2xl p-6 transition-all duration-300 hover:border-orange-main/30 hover:-translate-y-1">
      <div className="font-display text-4xl font-bold gradient-text-mixed">
        {value}
      </div>
      <div className="text-text-dim text-xs uppercase tracking-wide mt-1">
        {label}
      </div>
    </div>
  )
}
