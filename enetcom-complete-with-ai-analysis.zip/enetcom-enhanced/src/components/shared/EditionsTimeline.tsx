// components/shared/EditionsTimeline.tsx
export default function EditionsTimeline() {
  const editions = [
    { id: 1, year: 2020, title: 'The Foundation', description: "The inaugural ENET'COM Forum launched with 15 partner companies and 200 students. Focused on bridging the gap between engineering schools and the Tunisian tech industry.", studentCount: 200, companyCount: 15, placementCount: 12 },
    { id: 2, year: 2021, title: 'Going Digital', description: 'Adapted to the pandemic with the first fully online edition. Introduced video interviews and virtual company stands. Participation surged dramatically.', studentCount: 450, companyCount: 28, placementCount: 45 },
    { id: 3, year: 2022, title: 'Hybrid Innovation', description: 'Combined physical and virtual experiences for the first time. Added workshops and masterclasses. The hybrid model proved more inclusive than any previous format.', studentCount: 600, companyCount: 42, placementCount: 78 },
    { id: 4, year: 2023, title: 'VR Prototype Launch', description: 'First experiments with VR technology. Introduced a prototype virtual hall where students could explore company stands in 3D. A watershed moment for the platform.', studentCount: 800, companyCount: 55, placementCount: 120 },
    { id: 5, year: 2024, title: 'Full Immersion', description: 'Fully immersive VR experience rolled out. AI-powered matching, live networking rooms, and 3D portfolio presentations set a new industry standard.', studentCount: 1200, companyCount: 80, placementCount: 200 },
    { id: 6, year: 2025, title: 'Next Generation', description: 'The current edition features an advanced 3D platform, real-time collaboration tools, and expanded international partnerships. Aiming for unprecedented scale.', studentCount: 2000, companyCount: 120, placementCount: 0 },
  ]

  return (
    <section className="py-24 px-10 relative z-10">
      <div className="text-center mb-14">
        <h2 className="font-display text-3xl md:text-5xl font-bold gradient-text-blue mb-3">
          📅 Previous Editions
        </h2>
        <p className="text-text-dim text-lg">
          A journey through the history of ENET'COM Forum
        </p>
        <div className="w-20 h-1 mx-auto mt-5 bg-gradient-to-r from-blue-accent to-orange-main rounded-sm" />
      </div>

      <div className="relative max-w-4xl mx-auto py-5">
        {/* Vertical line */}
        <div className="absolute left-1/2 -translate-x-1/2 w-1 h-full bg-gradient-to-b from-blue-accent via-orange-main to-blue-accent rounded-sm hidden md:block" />

        {editions.map((edition, i) => (
          <div 
            key={edition.id}
            className={`
              flex flex-col md:flex-row items-start mb-10 relative
              ${i % 2 === 1 ? 'md:flex-row-reverse' : ''}
            `}
          >
            {/* Content card */}
            <div className="w-full md:w-[42%] bg-gradient-to-br from-blue-mid/70 to-blue-deep/90 border border-blue-accent/15 rounded-2xl p-7 transition-all duration-350 hover:border-orange-main/30 hover:scale-105 hover:shadow-[0_10px_40px_rgba(0,0,0,0.25)]">
              <div className="font-display text-xs text-orange-light tracking-[2px] uppercase mb-1.5">
                Edition {edition.id} — {edition.year}
              </div>
              <h3 className="text-lg text-text-white mb-2">{edition.title}</h3>
              <p className="text-text-dim text-sm leading-relaxed mb-3">
                {edition.description}
              </p>
              <div className="flex gap-3.5 flex-wrap text-text-dim text-xs font-mono">
                <span>👨‍🎓 {edition.studentCount} students</span>
                <span>🏢 {edition.companyCount} companies</span>
                {edition.placementCount > 0 && (
                  <span>📌 {edition.placementCount} placements</span>
                )}
              </div>
            </div>

            {/* Dot */}
            <div className="absolute left-1/2 -translate-x-1/2 top-3 w-4.5 h-4.5 bg-gradient-to-r from-orange-main to-blue-accent rounded-full border-[3px] border-blue-deep shadow-[0_0_12px_rgba(232,106,0,0.5)] hidden md:block" />
          </div>
        ))}
      </div>
    </section>
  )
}
