// components/shared/ConceptCards.tsx
export default function ConceptCards() {
  const cards = [
    { 
      icon: '🌐', 
      iconClass: 'blue', 
      title: 'Immersive VR Environment', 
      description: 'Navigate a fully rendered 3D virtual space that simulates real-world networking events. Meet companies, explore stands, and engage in live sessions — all from your browser.' 
    },
    { 
      icon: '🎯', 
      iconClass: 'orange', 
      title: 'Career Opportunity Matching', 
      description: 'Our AI-powered system matches students with the most relevant PFE projects, summer internships, and full-time jobs based on skills, interests, and academic profiles.' 
    },
    { 
      icon: '🤝', 
      iconClass: 'blue', 
      title: 'Industry Partnerships', 
      description: 'Partner with leading Tunisian and international companies. Build lasting connections that bridge the gap between academia and industry through structured collaboration.' 
    },
    { 
      icon: '📈', 
      iconClass: 'orange', 
      title: 'Skills Development', 
      description: 'Attend virtual workshops, masterclasses, and hackathons hosted by industry leaders. Sharpen technical and soft skills in a dynamic, interactive learning environment.' 
    },
    { 
      icon: '🚀', 
      iconClass: 'blue', 
      title: 'Innovation Hub', 
      description: 'Pitch your startup ideas, collaborate on open-source projects, and join innovation challenges sponsored by top tech companies in the region.' 
    },
    { 
      icon: '🏆', 
      iconClass: 'orange', 
      title: 'Competition & Awards', 
      description: 'Compete in coding challenges, design contests, and hackathons. Top performers receive scholarships, internship offers, and exclusive mentorship programs.' 
    },
  ]

  return (
    <section className="py-24 px-10 relative z-10 bg-gradient-to-b from-transparent via-blue-deep/95 to-blue-deep/98">
      <div className="text-center mb-16">
        <h2 className="font-display text-3xl md:text-5xl font-bold gradient-text-blue mb-3">
          🕶️ Virtual Reality Experience
        </h2>
        <p className="text-text-dim text-lg">
          Explore the forum's immersive concept and objectives
        </p>
        <div className="w-20 h-1 mx-auto mt-5 bg-gradient-to-r from-blue-accent to-orange-main rounded-sm" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7 max-w-6xl mx-auto">
        {cards.map((card, i) => (
          <div 
            key={i}
            className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/80 border border-blue-accent/15 rounded-2xl p-9 transition-all duration-400 relative overflow-hidden hover:border-orange-main/40 hover:-translate-y-1.5 hover:shadow-[0_20px_50px_rgba(0,0,0,0.3),0_0_30px_rgba(232,106,0,0.1)]"
          >
            <div className={`
              w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mb-5
              ${card.iconClass === 'blue' 
                ? 'bg-gradient-to-br from-blue-accent/20 to-blue-accent/5' 
                : 'bg-gradient-to-br from-orange-main/20 to-orange-main/5'}
            `}>
              {card.icon}
            </div>
            <h3 className="font-display text-lg font-bold text-text-white mb-3 tracking-wide">
              {card.title}
            </h3>
            <p className="text-text-dim text-sm leading-relaxed">
              {card.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}
