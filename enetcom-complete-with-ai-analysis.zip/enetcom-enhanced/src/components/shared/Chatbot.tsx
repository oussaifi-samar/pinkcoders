// src/components/shared/Chatbot.tsx
'use client'

import { useState, useRef, useEffect } from 'react'

interface Message {
  id: number
  text: string
  isBot: boolean
  timestamp: Date
}

const PREDEFINED_RESPONSES: Record<string, string> = {
  'offres': "Nous avons actuellement des offres PFE, stages d'été et emplois à temps plein. Allez sur la page Student Dashboard pour voir toutes les opportunités disponibles.",
  'pfe': "Les offres PFE sont des projets de fin d'études. Vous pouvez filtrer par type 'PFE' dans le dashboard étudiant pour voir toutes les offres disponibles.",
  'stage': "Nous proposons des stages d'été et des PFE. Consultez la section Student Dashboard pour postuler directement en ligne.",
  'postuler': "Pour postuler, allez dans Student Dashboard, trouvez l'offre qui vous intéresse et cliquez sur 'Apply Now'. Vous devrez remplir vos informations et télécharger votre CV.",
  'forum': "ENET'COM Forum est une plateforme VR qui connecte étudiants et entreprises. Consultez la page d'accueil pour découvrir notre concept et les éditions précédentes.",
  'entreprises': "Plus de 120 entreprises partenaires participent au forum. Vous pouvez voir leurs offres dans le Student Dashboard.",
  'contact': "Pour nous contacter, envoyez un email à forum@enetcom.tn ou visitez notre page Contact.",
  'cv': "Préparez un CV à jour (PDF), une lettre de motivation et votre relevé de notes. Certaines offres demandent aussi un portfolio.",
  'délai': "Les délais varient selon chaque offre. Consultez la date limite indiquée sur chaque carte d'offre dans le Student Dashboard.",
  'compétences': "Les compétences requises sont listées sur chaque offre. Utilisez les filtres pour trouver des offres correspondant à vos compétences.",
}

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Bonjour ! 👋 Je suis l'assistant virtuel ENET'COM Forum. Comment puis-je vous aider aujourd'hui ?",
      isBot: true,
      timestamp: new Date()
    }
  ])
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const findBestResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase()
    
    // Chercher une correspondance dans les réponses prédéfinies
    for (const [keyword, response] of Object.entries(PREDEFINED_RESPONSES)) {
      if (lowerMessage.includes(keyword)) {
        return response
      }
    }

    // Réponses contextuelles
    if (lowerMessage.includes('bonjour') || lowerMessage.includes('salut') || lowerMessage.includes('hello')) {
      return "Bonjour ! Je suis là pour répondre à vos questions sur ENET'COM Forum, les offres disponibles, et comment postuler. Que souhaitez-vous savoir ?"
    }
    
    if (lowerMessage.includes('merci')) {
      return "De rien ! N'hésitez pas si vous avez d'autres questions. Bonne chance dans vos candidatures ! 🎓"
    }

    if (lowerMessage.includes('aide') || lowerMessage.includes('help')) {
      return "Je peux vous aider avec :\n• Les offres disponibles (PFE, stages, emplois)\n• Comment postuler\n• Les entreprises partenaires\n• Les compétences requises\n• Les délais de candidature\n\nQue voulez-vous savoir ?"
    }

    // Réponse par défaut
    return "Je ne suis pas sûr de comprendre votre question. Essayez de me demander des informations sur les offres, comment postuler, ou le forum ENET'COM. Vous pouvez aussi taper 'aide' pour voir ce que je peux faire."
  }

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now(),
      text: input,
      isBot: false,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsTyping(true)

    // Simuler un délai de "réflexion" du bot
    setTimeout(() => {
      const botResponse: Message = {
        id: Date.now() + 1,
        text: findBestResponse(input),
        isBot: true,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, botResponse])
      setIsTyping(false)
    }, 1000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const QuickQuestion = ({ text }: { text: string }) => (
    <button
      onClick={() => {
        setInput(text)
        setTimeout(() => handleSend(), 100)
      }}
      className="text-xs px-3 py-1.5 rounded-full bg-blue-accent/20 text-blue-glow border border-blue-accent/30 hover:bg-blue-accent/30 transition-all duration-300"
    >
      {text}
    </button>
  )

  return (
    <>
      {/* Floating Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`
          fixed bottom-6 right-6 z-[999] 
          w-16 h-16 rounded-full 
          bg-gradient-to-r from-orange-main to-orange-deep 
          shadow-[0_8px_30px_rgba(232,106,0,0.4)]
          flex items-center justify-center
          transition-all duration-300 hover:scale-110
          ${isOpen ? 'rotate-90' : ''}
        `}
      >
        {isOpen ? (
          <span className="text-2xl">✕</span>
        ) : (
          <span className="text-2xl">💬</span>
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-[998] w-96 h-[600px] bg-gradient-to-br from-blue-mid/95 to-blue-deep/98 backdrop-blur-xl border border-blue-accent/20 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.5)] flex flex-col overflow-hidden animate-fade-in-up">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-accent to-orange-main px-6 py-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-xl">
              🤖
            </div>
            <div>
              <h3 className="font-display font-bold text-white">Assistant ENET'COM</h3>
              <p className="text-xs text-white/70">En ligne</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.isBot ? 'justify-start' : 'justify-end'} animate-fade-in-up`}
              >
                <div
                  className={`
                    max-w-[80%] px-4 py-2.5 rounded-2xl
                    ${msg.isBot
                      ? 'bg-blue-mid/60 text-text-white border border-blue-accent/20'
                      : 'bg-gradient-to-r from-orange-main to-orange-deep text-white'}
                  `}
                >
                  <p className="text-sm whitespace-pre-line">{msg.text}</p>
                  <span className="text-xs opacity-60 mt-1 block">
                    {msg.timestamp.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-blue-mid/60 text-text-white border border-blue-accent/20 px-4 py-2.5 rounded-2xl">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-blue-glow animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 rounded-full bg-blue-glow animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 rounded-full bg-blue-glow animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Questions */}
          <div className="px-4 py-2 flex gap-2 flex-wrap border-t border-blue-accent/10">
            <QuickQuestion text="Quelles offres disponibles ?" />
            <QuickQuestion text="Comment postuler ?" />
            <QuickQuestion text="Aide" />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-blue-accent/20">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Tapez votre question..."
                className="flex-1 bg-blue-mid/60 border border-blue-accent/20 rounded-full px-4 py-2.5 text-text-white text-sm focus:outline-none focus:border-orange-main transition-all duration-300"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim()}
                className="w-10 h-10 rounded-full bg-gradient-to-r from-orange-main to-orange-deep flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:scale-110 transition-all duration-300"
              >
                <span className="text-xl">➤</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
