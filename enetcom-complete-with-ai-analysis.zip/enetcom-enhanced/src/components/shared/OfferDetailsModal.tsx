// components/shared/OfferDetailsModal.tsx
'use client'

import { Offer, OfferType } from '@/types'

interface OfferDetailsModalProps {
  offer: Offer
  onClose: () => void
  onApply?: () => void
}

export default function OfferDetailsModal({ offer, onClose, onApply }: OfferDetailsModalProps) {
  const getTypeBadgeClass = (type: OfferType) => {
    switch (type) {
      case OfferType.PFE:
        return 'bg-blue-accent/20 text-blue-glow border-blue-accent/30'
      case OfferType.SUMMER:
        return 'bg-orange-main/20 text-orange-light border-orange-main/30'
      case OfferType.JOB:
        return 'bg-blue-glow/15 text-[#7bc4ff] border-blue-glow/25'
    }
  }

  const getTypeLabel = (type: OfferType) => {
    switch (type) {
      case OfferType.PFE:
        return 'PFE Project'
      case OfferType.SUMMER:
        return 'Summer Internship'
      case OfferType.JOB:
        return 'Full-Time Job'
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm px-4">
      <div className="bg-gradient-to-br from-blue-mid/95 to-blue-deep/95 border border-blue-accent/20 rounded-2xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-bold text-text-white">
            Offer <span className="text-orange-light">Details</span>
          </h2>
          <button
            onClick={onClose}
            className="text-text-dim hover:text-text-white transition-colors text-2xl"
          >
            ✕
          </button>
        </div>

        <div className="space-y-6">
          {/* Header */}
          <div>
            <span className={`inline-block px-3.5 py-1 rounded-full text-xs font-bold tracking-wide uppercase mb-4 border ${getTypeBadgeClass(offer.type)}`}>
              {getTypeLabel(offer.type)}
            </span>
            <h3 className="text-2xl font-display text-text-white mb-3">{offer.title}</h3>
            <div className="text-orange-light text-lg font-semibold mb-2">
              🏢 {offer.company}
            </div>
          </div>

          {/* Key Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-4">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Application Deadline
              </div>
              <div className="text-text-white text-lg font-semibold">
                📅 {new Date(offer.deadline).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>

            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-4">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Applicants
              </div>
              <div className="text-text-white text-lg font-semibold">
                📊 {offer.applicantCount || 0} students applied
              </div>
            </div>

            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-4">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Posted Date
              </div>
              <div className="text-text-white text-lg font-semibold">
                📆 {new Date(offer.postedAt).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>

            <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-4">
              <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Status
              </div>
              <div className="text-text-white text-lg font-semibold">
                {offer.status === 'open' ? '🟢 Open' : '🔴 Closed'}
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-5">
            <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-3">
              Description
            </div>
            <p className="text-text-white leading-relaxed text-base">
              {offer.description}
            </p>
          </div>

          {/* Required Skills */}
          <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-5">
            <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-3">
              Required Skills
            </div>
            <div className="flex flex-wrap gap-2">
              {offer.skills.map((skill, index) => (
                <span
                  key={index}
                  className="bg-gradient-to-r from-blue-accent/20 to-orange-main/20 border border-blue-accent/30 text-text-white px-4 py-2 rounded-full text-sm font-semibold"
                >
                  🔧 {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Additional Information */}
          <div className="bg-blue-mid/40 border border-blue-accent/15 rounded-xl p-5">
            <div className="text-text-dim text-xs uppercase tracking-wide font-semibold mb-3">
              About This Opportunity
            </div>
            <ul className="space-y-2 text-text-white">
              <li className="flex items-start gap-2">
                <span className="text-orange-light">•</span>
                <span>Competitive compensation package</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-light">•</span>
                <span>Mentorship from industry professionals</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-light">•</span>
                <span>Opportunity to work on real-world projects</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-light">•</span>
                <span>Professional development and training</span>
              </li>
            </ul>
          </div>

          {/* Action Buttons */}
          {onApply && (
            <div className="flex gap-3 justify-end pt-4">
              <button
                onClick={onClose}
                className="bg-blue-mid/60 border border-blue-accent/20 text-text-white font-body text-sm font-semibold px-6 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:bg-blue-mid/80"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onApply()
                  onClose()
                }}
                className="bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-sm font-bold px-8 py-3 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_6px_24px_rgba(232,106,0,0.4)] hover:-translate-y-0.5"
              >
                📤 Apply Now
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
