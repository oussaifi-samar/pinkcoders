// src/components/three/EnhancedThreeDBackground.tsx
'use client'

import { useEffect, useRef } from 'react'

declare const THREE: any

export default function EnhancedThreeDBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current || typeof THREE === 'undefined') return

    const canvas = canvasRef.current
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setClearColor(0x000000, 0)

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.set(0, 0, 80)

    // ══════════════════════════════════════════════════════════
    // FLOATING POLYHEDRA — Plus nombreux et variés
    // ══════════════════════════════════════════════════════════
    const geometries = [
      new THREE.IcosahedronGeometry(6, 0),
      new THREE.IcosahedronGeometry(4, 1),
      new THREE.IcosahedronGeometry(3, 0),
      new THREE.OctahedronGeometry(5, 0),
      new THREE.OctahedronGeometry(3, 0),
      new THREE.TetrahedronGeometry(4, 0),
      new THREE.DodecahedronGeometry(3.5, 0),
      new THREE.TorusGeometry(3, 0.8, 16, 100),
    ]

    const meshes: Array<{ 
      mesh: any
      speed: number
      offsetX: number
      offsetY: number
      rotationSpeed: { x: number; y: number; z: number }
    }> = []

    geometries.forEach((geo: any, i: number) => {
      const isOrange = i % 2 === 1
      const mat = new THREE.MeshPhysicalMaterial({
        color:             isOrange ? 0xe86a00 : 0x2e86de,
        transparent:       true,
        opacity:           0.15,
        wireframe:         true,
        emissive:          isOrange ? 0xc44400 : 0x1a4a8a,
        emissiveIntensity: 0.4,
        metalness:         0.3,
        roughness:         0.7,
      })
      const mesh = new THREE.Mesh(geo, mat)
      
      const spread = 60
      mesh.position.set(
        (Math.random() - 0.5) * spread,
        (Math.random() - 0.5) * spread * 0.8,
        (Math.random() - 0.5) * 35
      )
      
      mesh.rotation.set(
        Math.random() * Math.PI, 
        Math.random() * Math.PI, 
        Math.random() * Math.PI
      )
      
      scene.add(mesh)
      
      meshes.push({ 
        mesh, 
        speed: 0.15 + Math.random() * 0.35, 
        offsetX: Math.random() * Math.PI * 2, 
        offsetY: Math.random() * Math.PI * 2,
        rotationSpeed: {
          x: 0.003 + Math.random() * 0.005,
          y: 0.004 + Math.random() * 0.006,
          z: 0.002 + Math.random() * 0.003,
        }
      })
    })

    // ══════════════════════════════════════════════════════════
    // CONNECTING LINES — Entre les polyèdres
    // ══════════════════════════════════════════════════════════
    const lineMat = new THREE.LineBasicMaterial({ 
      color: 0x2e86de, 
      transparent: true, 
      opacity: 0.1 
    })
    
    const lines: any[] = []
    for (let i = 0; i < meshes.length; i++) {
      for (let j = i + 1; j < meshes.length; j++) {
        const distance = meshes[i].mesh.position.distanceTo(meshes[j].mesh.position)
        if (distance < 40) {
          const pts = [meshes[i].mesh.position.clone(), meshes[j].mesh.position.clone()]
          const geo = new THREE.BufferGeometry().setFromPoints(pts)
          const line = new THREE.Line(geo, lineMat)
          scene.add(line)
          lines.push({ line, i, j })
        }
      }
    }

    // ══════════════════════════════════════════════════════════
    // LIGHTS — Dynamiques avec couleurs
    // ══════════════════════════════════════════════════════════
    scene.add(new THREE.AmbientLight(0xffffff, 0.3))
    
    const pointLight1 = new THREE.PointLight(0x2e86de, 2, 250)
    pointLight1.position.set(40, 25, 50)
    scene.add(pointLight1)
    
    const pointLight2 = new THREE.PointLight(0xe86a00, 1.8, 250)
    pointLight2.position.set(-40, -20, 40)
    scene.add(pointLight2)

    const pointLight3 = new THREE.PointLight(0x4da6ff, 1.5, 200)
    pointLight3.position.set(0, 40, 30)
    scene.add(pointLight3)

    // ══════════════════════════════════════════════════════════
    // PARTICLE SYSTEM — Étoiles animées
    // ══════════════════════════════════════════════════════════
    const particleCount = 500
    const particlesGeo = new THREE.BufferGeometry()
    const positions = new Float32Array(particleCount * 3)
    const colors = new Float32Array(particleCount * 3)
    const sizes = new Float32Array(particleCount)

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 150
      positions[i * 3 + 1] = (Math.random() - 0.5) * 150
      positions[i * 3 + 2] = (Math.random() - 0.5) * 80

      const isBlue = Math.random() > 0.5
      colors[i * 3] = isBlue ? 0.18 : 0.91
      colors[i * 3 + 1] = isBlue ? 0.53 : 0.42
      colors[i * 3 + 2] = isBlue ? 0.87 : 0

      sizes[i] = Math.random() * 0.5 + 0.2
    }

    particlesGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    particlesGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    particlesGeo.setAttribute('size', new THREE.BufferAttribute(sizes, 1))

    const particlesMat = new THREE.PointsMaterial({
      size: 0.4,
      vertexColors: true,
      transparent: true,
      opacity: 0.6,
      sizeAttenuation: true,
      blending: THREE.AdditiveBlending,
    })

    const particleSystem = new THREE.Points(particlesGeo, particlesMat)
    scene.add(particleSystem)

    // ══════════════════════════════════════════════════════════
    // FLOATING DOTS — Petites sphères lumineuses
    // ══════════════════════════════════════════════════════════
    const dotsGeo = new THREE.BufferGeometry()
    const dotsCount = 300
    const dotsPositions = new Float32Array(dotsCount * 3)
    
    for (let i = 0; i < dotsCount * 3; i++) {
      dotsPositions[i] = (Math.random() - 0.5) * 140
    }
    
    dotsGeo.setAttribute('position', new THREE.BufferAttribute(dotsPositions, 3))
    const dotsMat = new THREE.PointsMaterial({ 
      color: 0x4da6ff, 
      size: 0.3, 
      transparent: true, 
      opacity: 0.5 
    })
    scene.add(new THREE.Points(dotsGeo, dotsMat))

    // ══════════════════════════════════════════════════════════
    // ANIMATION LOOP
    // ══════════════════════════════════════════════════════════
    let t = 0
    let animId: number

    function animate() {
      animId = requestAnimationFrame(animate)
      t += 0.008

      // Animer les polyèdres
      meshes.forEach(m => {
        m.mesh.rotation.x += m.rotationSpeed.x * m.speed
        m.mesh.rotation.y += m.rotationSpeed.y * m.speed
        m.mesh.rotation.z += m.rotationSpeed.z * m.speed
        
        m.mesh.position.y += Math.sin(t + m.offsetY) * 0.02
        m.mesh.position.x += Math.sin(t * 0.5 + m.offsetX) * 0.01
      })

      // Mettre à jour les lignes
      lines.forEach(({ line, i, j }) => {
        const pts = [meshes[i].mesh.position.clone(), meshes[j].mesh.position.clone()]
        line.geometry.setFromPoints(pts)
      })

      // Animer les particules
      const positions = particlesGeo.attributes.position.array as Float32Array
      for (let i = 0; i < particleCount; i++) {
        positions[i * 3 + 1] += Math.sin(t + i * 0.1) * 0.02
      }
      particlesGeo.attributes.position.needsUpdate = true

      // Rotation du système de particules
      particleSystem.rotation.y += 0.0005

      // Animer les lumières
      pointLight1.position.x = Math.sin(t * 0.5) * 50
      pointLight2.position.z = Math.cos(t * 0.3) * 50
      pointLight3.position.y = Math.sin(t * 0.7) * 40 + 30

      // Mouvement subtil de la caméra
      camera.position.x += (Math.sin(t * 0.3) * 5 - camera.position.x) * 0.008
      camera.position.y += (Math.cos(t * 0.2) * 3 - camera.position.y) * 0.008

      renderer.render(scene, camera)
    }

    animate()

    // ══════════════════════════════════════════════════════════
    // MOUSE INTERACTION
    // ══════════════════════════════════════════════════════════
    const mouse = { x: 0, y: 0 }
    
    const handleMouseMove = (event: MouseEvent) => {
      mouse.x = (event.clientX / window.innerWidth) * 2 - 1
      mouse.y = -(event.clientY / window.innerHeight) * 2 + 1
      
      // La caméra suit légèrement la souris
      camera.position.x += (mouse.x * 10 - camera.position.x) * 0.05
      camera.position.y += (mouse.y * 10 - camera.position.y) * 0.05
      camera.lookAt(0, 0, 0)
    }

    window.addEventListener('mousemove', handleMouseMove)

    // ══════════════════════════════════════════════════════════
    // RESIZE HANDLER
    // ══════════════════════════════════════════════════════════
    const handleResize = () => {
      renderer.setSize(window.innerWidth, window.innerHeight)
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
    }

    window.addEventListener('resize', handleResize)

    // ══════════════════════════════════════════════════════════
    // CLEANUP
    // ══════════════════════════════════════════════════════════
    return () => {
      cancelAnimationFrame(animId)
      window.removeEventListener('resize', handleResize)
      window.removeEventListener('mousemove', handleMouseMove)
      renderer.dispose()
    }
  }, [])

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 pointer-events-none"
    />
  )
}
