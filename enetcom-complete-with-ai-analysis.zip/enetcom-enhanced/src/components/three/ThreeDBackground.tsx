// components/three/ThreeDBackground.tsx
'use client'

import { useEffect, useRef } from 'react'

// Three.js will be loaded via CDN in the HTML head
declare const THREE: any

export default function ThreeDBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current || typeof THREE === 'undefined') return

    const canvas = canvasRef.current
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(window.devicePixelRatio)
    renderer.setClearColor(0x000000, 0)

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.set(0, 0, 80)

    // ── Floating polyhedra ──
    const geometries = [
      new THREE.IcosahedronGeometry(6, 0),
      new THREE.IcosahedronGeometry(3.5, 0),
      new THREE.IcosahedronGeometry(2, 0),
      new THREE.OctahedronGeometry(4, 0),
      new THREE.OctahedronGeometry(2.5, 0),
    ]

    const meshes: Array<{ mesh: any; speed: number; offsetX: number; offsetY: number }> = []

    geometries.forEach((geo: any, i: number) => {
      const mat = new THREE.MeshPhysicalMaterial({
        color:             i % 2 === 0 ? 0x2e86de : 0xe86a00,
        transparent:       true,
        opacity:           0.12,
        wireframe:         true,
        emissive:          i % 2 === 0 ? 0x1a4a8a : 0xc44400,
        emissiveIntensity: 0.3,
      })
      const mesh = new THREE.Mesh(geo, mat)
      const spread = 55
      mesh.position.set(
        (Math.random() - 0.5) * spread,
        (Math.random() - 0.5) * spread * 0.7,
        (Math.random() - 0.5) * 30
      )
      mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0)
      scene.add(mesh)
      meshes.push({ 
        mesh, 
        speed: 0.2 + Math.random() * 0.3, 
        offsetX: Math.random() * Math.PI * 2, 
        offsetY: Math.random() * Math.PI * 2 
      })
    })

    // ── Connecting lines ──
    const lineMat = new THREE.LineBasicMaterial({ color: 0x2e86de, transparent: true, opacity: 0.08 })
    for (let i = 0; i < meshes.length; i++) {
      for (let j = i + 1; j < meshes.length; j++) {
        const pts = [meshes[i].mesh.position.clone(), meshes[j].mesh.position.clone()]
        const geo = new THREE.BufferGeometry().setFromPoints(pts)
        scene.add(new THREE.Line(geo, lineMat))
      }
    }

    // ── Lights ──
    scene.add(new THREE.AmbientLight(0xffffff, 0.4))
    const pl1 = new THREE.PointLight(0x2e86de, 1.5, 200)
    pl1.position.set(30, 20, 40)
    scene.add(pl1)
    const pl2 = new THREE.PointLight(0xe86a00, 1.2, 200)
    pl2.position.set(-30, -15, 30)
    scene.add(pl2)

    // ── Floating dots ──
    const dotsGeo = new THREE.BufferGeometry()
    const positions = new Float32Array(300 * 3)
    for (let i = 0; i < positions.length; i++) positions[i] = (Math.random() - 0.5) * 140
    dotsGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    scene.add(new THREE.Points(dotsGeo, new THREE.PointsMaterial({ 
      color: 0x4da6ff, 
      size: 0.25, 
      transparent: true, 
      opacity: 0.5 
    })))

    // ── Animation loop ──
    let t = 0
    let animId: number

    function animate() {
      animId = requestAnimationFrame(animate)
      t += 0.008

      meshes.forEach(m => {
        m.mesh.rotation.x += 0.004 * m.speed
        m.mesh.rotation.y += 0.006 * m.speed
        m.mesh.position.y += Math.sin(t + m.offsetY) * 0.015
        m.mesh.position.x += Math.sin(t * 0.5 + m.offsetX) * 0.008
      })

      camera.position.x += (Math.sin(t * 0.3) * 5 - camera.position.x) * 0.01
      camera.position.y += (Math.cos(t * 0.2) * 3 - camera.position.y) * 0.01

      renderer.render(scene, camera)
    }

    animate()

    // ── Resize handler ──
    const handleResize = () => {
      renderer.setSize(window.innerWidth, window.innerHeight)
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
    }

    window.addEventListener('resize', handleResize)

    // ── Cleanup ──
    return () => {
      cancelAnimationFrame(animId)
      window.removeEventListener('resize', handleResize)
      renderer.dispose()
    }
  }, [])

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 pointer-events-none"
    />
  )
}
