// components/auth/ProtectedRoute.tsx
'use client'

import { useEffect, ReactNode } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import { UserRole } from '@/types'

interface ProtectedRouteProps {
  children: ReactNode
  allowedRole: UserRole
}

export default function ProtectedRoute({ children, allowedRole }: ProtectedRouteProps) {
  const { user, isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    } else if (user && user.role !== allowedRole) {
      // Redirect to appropriate dashboard based on user role
      switch (user.role) {
        case UserRole.STUDENT:
          router.push('/student')
          break
        case UserRole.COMPANY:
          router.push('/company')
          break
        case UserRole.ADMIN:
          router.push('/admin')
          break
      }
    }
  }, [isAuthenticated, user, allowedRole, router])

  if (!isAuthenticated || (user && user.role !== allowedRole)) {
    return (
      <div className="relative z-10 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin text-4xl mb-4">⏳</div>
          <p className="text-text-white text-lg">Loading...</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
