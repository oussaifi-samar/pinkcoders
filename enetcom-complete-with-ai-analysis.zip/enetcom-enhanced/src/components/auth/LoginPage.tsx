// components/auth/LoginPage.tsx
'use client'

import { useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { UserRole } from '@/types'

export default function LoginPage() {
  const { login } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showCredentials, setShowCredentials] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const success = await login(email, password)
      if (!success) {
        setError('Invalid email or password')
      }
    } catch (err) {
      setError('An error occurred. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const quickLogin = (role: UserRole) => {
    const credentials = {
      [UserRole.STUDENT]: { email: 'student@enetcom.tn', password: 'student123' },
      [UserRole.COMPANY]: { email: 'company@enetcom.tn', password: 'company123' },
      [UserRole.ADMIN]: { email: 'admin@enetcom.tn', password: 'admin123' },
    }
    
    const creds = credentials[role]
    setEmail(creds.email)
    setPassword(creds.password)
  }

  return (
    <section className="relative z-10 min-h-screen flex items-center justify-center px-6 py-16">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-block bg-gradient-to-r from-orange-main/15 to-blue-accent/15 border border-orange-main/40 text-orange-light px-6 py-2 rounded-full text-xs font-semibold tracking-[3px] uppercase mb-6">
            🔐 SECURE LOGIN
          </div>
          <h1 className="font-display text-4xl font-bold text-text-white mb-3">
            Welcome to <span className="text-orange-light">ENET'COM Forum</span>
          </h1>
          <p className="text-text-dim text-base">
            Sign in to access your dashboard and explore opportunities
          </p>
        </div>

        {/* Login Form */}
        <div className="bg-gradient-to-br from-blue-mid/60 to-blue-deep/85 border border-blue-accent/15 rounded-2xl p-8 shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@enetcom.tn"
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              />
            </div>

            <div>
              <label className="block text-text-dim text-xs uppercase tracking-wide font-semibold mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                className="w-full bg-blue-mid/60 border border-blue-accent/20 rounded-xl px-4 py-3 text-text-white font-body text-sm transition-all duration-300 focus:outline-none focus:border-orange-main focus:shadow-[0_0_16px_rgba(232,106,0,0.2)]"
              />
            </div>

            {error && (
              <div className="bg-[#e74c3c]/20 border border-[#e74c3c]/40 text-[#ff7b7b] px-4 py-3 rounded-xl text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-orange-main to-orange-deep text-white font-body text-base font-bold px-8 py-3.5 rounded-full uppercase tracking-wide transition-all duration-300 hover:shadow-[0_6px_24px_rgba(232,106,0,0.4)] hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '⏳ Signing in...' : '🚀 Sign In'}
            </button>
          </form>

          {/* Demo Credentials Toggle */}
          <div className="mt-6 pt-6 border-t border-blue-accent/20">
            <button
              onClick={() => setShowCredentials(!showCredentials)}
              className="w-full text-text-dim hover:text-orange-light text-sm font-semibold transition-colors flex items-center justify-center gap-2"
            >
              {showCredentials ? '🔼 Hide' : '🔽 Show'} Demo Credentials
            </button>

            {showCredentials && (
              <div className="mt-4 space-y-3">
                <p className="text-text-dim text-xs text-center mb-3">
                  Quick login options for testing:
                </p>
                
                <button
                  type="button"
                  onClick={() => quickLogin(UserRole.STUDENT)}
                  className="w-full bg-blue-accent/20 border border-blue-accent/30 text-text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 hover:bg-blue-accent/30 hover:border-blue-accent/50"
                >
                  🎓 Student Login
                  <span className="block text-xs text-text-dim mt-1">student@enetcom.tn</span>
                </button>

                <button
                  type="button"
                  onClick={() => quickLogin(UserRole.COMPANY)}
                  className="w-full bg-orange-main/20 border border-orange-main/30 text-text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 hover:bg-orange-main/30 hover:border-orange-main/50"
                >
                  🏢 Company Login
                  <span className="block text-xs text-text-dim mt-1">company@enetcom.tn</span>
                </button>

                <button
                  type="button"
                  onClick={() => quickLogin(UserRole.ADMIN)}
                  className="w-full bg-blue-glow/15 border border-blue-glow/25 text-text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 hover:bg-blue-glow/25 hover:border-blue-glow/40"
                >
                  ⚙️ Admin Login
                  <span className="block text-xs text-text-dim mt-1">admin@enetcom.tn</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-6 text-center">
          <p className="text-text-dim text-sm">
            Don't have an account?{' '}
            <a href="#" className="text-orange-light hover:underline font-semibold">
              Contact Administration
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
