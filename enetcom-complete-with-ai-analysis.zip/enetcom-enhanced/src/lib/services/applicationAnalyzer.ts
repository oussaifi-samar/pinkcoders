// src/lib/services/applicationAnalyzer.ts
import { ApplicationFormData } from '@/types/student'
import { Offer } from '@/types'

export interface AnalysisResult {
  acceptanceProbability: number  // 0-100
  matchScore: number              // 0-100
  strengths: string[]
  improvements: string[]
  recommendation: 'highly_recommended' | 'recommended' | 'possible' | 'not_recommended'
  breakdown: {
    gpa: number
    experience: number
    skills: number
    coverLetter: number
  }
}

export class ApplicationAnalyzer {
  
  /**
   * Analyse la candidature et retourne un score de matching
   */
  static analyze(application: ApplicationFormData, offer: Offer): AnalysisResult {
    const breakdown = {
      gpa: this.analyzeGPA(application.gpa),
      experience: this.analyzeExperience(application.year),
      skills: this.analyzeSkills(application, offer),
      coverLetter: this.analyzeCoverLetter(application.coverLetter)
    }

    // Calcul du score global (moyenne pondérée)
    const weights = {
      gpa: 0.25,
      experience: 0.20,
      skills: 0.35,
      coverLetter: 0.20
    }

    const matchScore = Math.round(
      breakdown.gpa * weights.gpa +
      breakdown.experience * weights.experience +
      breakdown.skills * weights.skills +
      breakdown.coverLetter * weights.coverLetter
    )

    // Probabilité d'acceptation (avec facteur de randomness pour réalisme)
    const baseProbability = matchScore
    const randomFactor = Math.floor(Math.random() * 10) - 5  // -5 à +5
    const acceptanceProbability = Math.max(10, Math.min(95, baseProbability + randomFactor))

    // Identification des forces et faiblesses
    const strengths = this.identifyStrengths(breakdown, application, offer)
    const improvements = this.identifyImprovements(breakdown, application, offer)

    // Recommandation
    const recommendation = this.getRecommendation(acceptanceProbability)

    return {
      acceptanceProbability,
      matchScore,
      strengths,
      improvements,
      recommendation,
      breakdown
    }
  }

  /**
   * Analyse le GPA (0-100)
   */
  private static analyzeGPA(gpa: number): number {
    if (gpa >= 3.7) return 95
    if (gpa >= 3.5) return 90
    if (gpa >= 3.3) return 85
    if (gpa >= 3.0) return 75
    if (gpa >= 2.8) return 65
    if (gpa >= 2.5) return 50
    return 30
  }

  /**
   * Analyse l'expérience basée sur l'année (0-100)
   */
  private static analyzeExperience(year: number): number {
    // Plus l'étudiant est avancé, plus il a d'expérience
    if (year === 5) return 95
    if (year === 4) return 85
    if (year === 3) return 70
    if (year === 2) return 50
    return 30
  }

  /**
   * Analyse la correspondance des compétences (0-100)
   */
  private static analyzeSkills(application: ApplicationFormData, offer: Offer): number {
    const coverLetterLower = application.coverLetter.toLowerCase()
    const majorLower = application.major.toLowerCase()
    
    let matchCount = 0
    const requiredSkills = offer.skills

    // Vérifier la présence des compétences dans la lettre de motivation et le major
    requiredSkills.forEach(skill => {
      const skillLower = skill.toLowerCase()
      if (coverLetterLower.includes(skillLower) || majorLower.includes(skillLower)) {
        matchCount++
      }
    })

    // Score basé sur le pourcentage de compétences mentionnées
    const percentage = requiredSkills.length > 0 
      ? (matchCount / requiredSkills.length) * 100 
      : 50

    return Math.round(percentage)
  }

  /**
   * Analyse la qualité de la lettre de motivation (0-100)
   */
  private static analyzeCoverLetter(coverLetter: string): number {
    const wordCount = coverLetter.trim().split(/\s+/).length
    
    // Longueur idéale : 150-300 mots
    let lengthScore = 0
    if (wordCount >= 150 && wordCount <= 300) lengthScore = 100
    else if (wordCount >= 100 && wordCount < 150) lengthScore = 80
    else if (wordCount >= 50 && wordCount < 100) lengthScore = 60
    else lengthScore = 40

    // Bonus pour mots-clés professionnels
    const professionalKeywords = [
      'experience', 'passion', 'skills', 'team', 'project', 
      'motivated', 'dedicated', 'contribute', 'learn', 'develop'
    ]
    
    let keywordBonus = 0
    const lowerText = coverLetter.toLowerCase()
    professionalKeywords.forEach(keyword => {
      if (lowerText.includes(keyword)) keywordBonus += 2
    })

    return Math.min(100, lengthScore + keywordBonus)
  }

  /**
   * Identifie les forces du candidat
   */
  private static identifyStrengths(
    breakdown: AnalysisResult['breakdown'], 
    application: ApplicationFormData, 
    offer: Offer
  ): string[] {
    const strengths: string[] = []

    if (breakdown.gpa >= 85) {
      strengths.push(`Excellent GPA (${application.gpa}/4.0) — Top candidat académique`)
    }

    if (breakdown.experience >= 80) {
      strengths.push(`Niveau d'études avancé (${this.getYearLabel(application.year)}) — Bonne expérience`)
    }

    if (breakdown.skills >= 70) {
      strengths.push(`Compétences techniques alignées — Maîtrise des technologies demandées`)
    }

    if (breakdown.coverLetter >= 80) {
      strengths.push('Lettre de motivation convaincante — Forte motivation démontrée')
    }

    if (application.major.toLowerCase().includes('computer') || 
        application.major.toLowerCase().includes('software') ||
        application.major.toLowerCase().includes('engineering')) {
      strengths.push('Formation pertinente — Parcours académique aligné avec le poste')
    }

    return strengths
  }

  /**
   * Identifie les points à améliorer
   */
  private static identifyImprovements(
    breakdown: AnalysisResult['breakdown'], 
    application: ApplicationFormData, 
    offer: Offer
  ): string[] {
    const improvements: string[] = []

    if (breakdown.gpa < 70) {
      improvements.push('Améliorer votre moyenne académique pour renforcer votre profil')
    }

    if (breakdown.skills < 60) {
      const missingSkills = offer.skills.filter(skill => 
        !application.coverLetter.toLowerCase().includes(skill.toLowerCase())
      )
      if (missingSkills.length > 0) {
        improvements.push(`Mentionner vos compétences en ${missingSkills.slice(0, 2).join(', ')}`)
      }
    }

    if (breakdown.coverLetter < 70) {
      const wordCount = application.coverLetter.trim().split(/\s+/).length
      if (wordCount < 100) {
        improvements.push('Développer davantage votre lettre de motivation (min 150 mots recommandés)')
      } else {
        improvements.push('Mettre plus en avant vos expériences et motivations concrètes')
      }
    }

    if (breakdown.experience < 60) {
      improvements.push('Acquérir plus d\'expérience pratique à travers des projets personnels')
    }

    return improvements
  }

  /**
   * Détermine la recommandation globale
   */
  private static getRecommendation(probability: number): AnalysisResult['recommendation'] {
    if (probability >= 75) return 'highly_recommended'
    if (probability >= 60) return 'recommended'
    if (probability >= 40) return 'possible'
    return 'not_recommended'
  }

  /**
   * Convertit l'année en label
   */
  private static getYearLabel(year: number): string {
    const labels = ['', '1ère année', '2ème année', '3ème année', '4ème année', '5ème année']
    return labels[year] || `${year}ème année`
  }
}
