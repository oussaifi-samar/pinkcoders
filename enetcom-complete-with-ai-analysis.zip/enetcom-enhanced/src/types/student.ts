// types/student.ts
// Extended student profile interface

export interface StudentProfile {
  id: number;
  name: string;
  email: string;
  phone: string;
  gpa: number;
  major: string;
  year: number;
  skills: string[];
  bio: string;
  cvUrl?: string;
  appliedOffers: number[];
  createdAt: string;
}

export interface ApplicationFormData {
  studentName: string;
  studentEmail: string;
  studentPhone: string;
  gpa: number;
  major: string;
  year: number;
  coverLetter: string;
  cvFile?: File;
}
