// ============================================================
// types/index.ts
// All domain models, enums, and DTOs in one place.
// ============================================================

// ─── Enums ────────────────────────────────────────────────
export enum OfferType {
  PFE    = 'pfe',
  SUMMER = 'summer',
  JOB    = 'job'
}

export enum OfferStatus {
  OPEN   = 'open',
  CLOSED = 'closed'
}

export enum ApplicationStatus {
  PENDING  = 'pending',
  ACCEPTED = 'accepted',
  REJECTED = 'rejected'
}

export enum UserRole {
  STUDENT = 'student',
  COMPANY = 'company',
  ADMIN   = 'admin'
}

// ─── Interfaces ───────────────────────────────────────────
export interface Offer {
  id:              number;
  title:           string;
  company:         string;
  type:            OfferType;
  status:          OfferStatus;
  deadline:        string;
  skills:          string[];
  description:     string;
  postedAt:        string;
  applicantCount?: number;
}

export interface Application {
  id:          number;
  offerId:     number;
  offerTitle:  string;
  studentId:   number;
  studentName: string;
  status:      ApplicationStatus;
  gpa:         number;
  skills:      string[];
  appliedAt:   string;
}

export interface Company {
  id:         number;
  name:       string;
  sector:     string;
  logoUrl?:   string;
  offerCount: number;
  createdAt:  string;
}

export interface User {
  id:    number;
  email: string;
  name:  string;
  role:  UserRole;
  token?: string;
}

export interface Edition {
  id:             number;
  year:           number;
  title:          string;
  description:    string;
  studentCount:   number;
  companyCount:   number;
  placementCount: number;
}

// ─── DTOs ─────────────────────────────────────────────────
export interface CreateOfferDto {
  title:       string;
  type:        OfferType;
  deadline:    string;
  description: string;
}

export interface CreateCompanyDto {
  name:    string;
  sector:  string;
  logoUrl?: string;
}

export interface LoginDto {
  email:    string;
  password: string;
}

// ─── API Response Envelope ────────────────────────────────
export interface ApiResponse<T> {
  data:    T;
  status:  number;
  message: string;
}
