# ENET'COM Forum — Installation Guide

## Prerequisites

- **Node.js** 18.17 or higher
- **npm** or **yarn** package manager
- **Git** (optional, for version control)

## Installation Steps

### 1. Extract & Navigate

```bash
# Extract the zip file
unzip enetcom-forum-nextjs.zip

# Navigate to project
cd enetcom-nextjs
```

### 2. Install Dependencies

```bash
npm install
# or
yarn install
```

This will install:
- Next.js 14 (App Router)
- React 18
- TypeScript
- Tailwind CSS
- Three.js
- Type definitions

### 3. Run Development Server

```bash
npm run dev
# or
yarn dev
```

The application will start at **http://localhost:3000**

### 4. Build for Production

```bash
npm run build
npm start
```

## Project Structure Explained

### `/src/app/` — Pages & Routes
Each folder becomes a route:
- `page.tsx` → `/`
- `student/page.tsx` → `/student`
- `company/page.tsx` → `/company`
- `admin/page.tsx` → `/admin`

### `/src/components/` — Reusable UI
- `shared/` — Components used across multiple pages
- `three/` — Three.js 3D background component

### `/src/types/` — TypeScript Definitions
All interfaces and enums in one barrel file

### `/src/lib/` — Business Logic
- `services/` — API calls (to be implemented)
- `hooks/` — Custom React hooks
- `utils/` — Helper functions

## Configuration Files

### `tailwind.config.ts`
Custom color palette and animations:
```typescript
colors: {
  blue: { deep, mid, light, accent, glow },
  orange: { deep, main, light, glow }
}
```

### `tsconfig.json`
TypeScript configuration with path aliases:
```json
"paths": { "@/*": ["./src/*"] }
```

### `next.config.js`
Next.js configuration (React strict mode enabled)

## Key Features

### Server Components (Default)
- `app/page.tsx` — Home page
- `components/shared/ConceptCards.tsx`
- `components/shared/EditionsTimeline.tsx`

These render on the server — no client-side JS needed.

### Client Components (`'use client'`)
- `components/three/ThreeDBackground.tsx` — Three.js canvas
- `app/student/page.tsx` — Interactive dashboard
- `app/company/page.tsx` — Form submissions
- `app/admin/page.tsx` — Tabbed interface

## Customization Guide

### Change Colors
Edit `tailwind.config.ts`:
```typescript
colors: {
  blue: { 
    deep: '#YOUR_COLOR' 
  }
}
```

### Add New Page
1. Create folder in `src/app/`
2. Add `page.tsx` file
3. Export default component

Example:
```typescript
// src/app/about/page.tsx
export default function AboutPage() {
  return <div>About Us</div>
}
```

### Connect to API
Replace mock data in page components:

```typescript
// Before (mock)
const offers = MOCK_OFFERS

// After (API)
const offers = await fetch('/api/offers').then(r => r.json())
```

## Common Issues & Solutions

### Port 3000 Already in Use
```bash
# Kill the process
lsof -ti:3000 | xargs kill -9

# Or use different port
npm run dev -- -p 3001
```

### TypeScript Errors
```bash
# Clear Next.js cache
rm -rf .next
npm run dev
```

### Tailwind Styles Not Working
```bash
# Rebuild Tailwind
npm run build
```

## Deployment

### Vercel (Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## Environment Variables

Create `.env.local` for secrets:
```env
NEXT_PUBLIC_API_URL=https://api.enetcom.tn
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
```

Access in code:
```typescript
const apiUrl = process.env.NEXT_PUBLIC_API_URL
```

## Next Steps

1. **Backend Integration**
   - Create API routes in `app/api/`
   - Connect to database (PostgreSQL, MongoDB, etc.)
   - Implement authentication

2. **Enhanced 3D**
   - Add interactive elements to canvas
   - Implement VR mode
   - Create animated transitions

3. **Testing**
   - Add Jest + React Testing Library
   - Write unit tests for components
   - E2E tests with Playwright

4. **Performance**
   - Optimize images with `next/image`
   - Implement lazy loading
   - Add ISR (Incremental Static Regeneration)

## Resources

- [Next.js Docs](https://nextjs.org/docs)
- [Tailwind Docs](https://tailwindcss.com)
- [Three.js Examples](https://threejs.org/examples/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)

## Support

For questions or issues:
1. Check the README.md
2. Review ARCHITECTURE.md
3. Consult Next.js documentation
4. Search GitHub issues

---

**Built with ❤️ for ENET'COM Forum 2025**
