# ENET'COM Forum — Next.js Platform

A cutting-edge digital platform connecting students, companies, and opportunities in an immersive 3D virtual reality experience.

## Tech Stack

- **Next.js 14** (App Router)
- **React 18** (Server & Client Components)
- **TypeScript** (Strict mode)
- **Tailwind CSS** (Utility-first styling)
- **Three.js** (3D background canvas)

## Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

```
src/
├── app/                    # App Router pages
│   ├── layout.tsx          # Root layout (nav + 3D background)
│   ├── page.tsx            # Home page
│   ├── student/page.tsx    # Student dashboard
│   ├── company/page.tsx    # Company dashboard
│   └── admin/page.tsx      # Admin dashboard
│
├── components/
│   ├── shared/             # Reusable UI components
│   └── three/              # Three.js 3D background
│
├── types/
│   └── index.ts            # TypeScript models
│
└── lib/
    ├── services/           # API calls
    ├── hooks/              # Custom React hooks
    └── utils/              # Helper functions
```

## Features

### 🏠 Home Page
- Cinematic hero with animated 3D background
- VR concept cards (6 feature highlights)
- Timeline of previous editions (2020-2025)

### 🎓 Student Dashboard
- Filterable job offers (PFE, Summer, Full-Time)
- Live stats (offers count, applications sent)
- Apply to opportunities with one click

### 🏢 Company Dashboard
- Post new offers (form with validation)
- Review incoming applications
- Accept/reject candidates

### ⚙️ Admin Dashboard
- View all offers across companies
- Track application statuses
- Manage partner companies (add/remove)

## Architecture Highlights

### Server vs Client Components
- **Server Components** (default): Home page, concept cards, timeline
- **Client Components**: 3D canvas, dashboards, forms, navigation

### Styling Strategy
- Tailwind utility classes for rapid development
- Custom color palette (blue/orange gradient theme)
- CSS custom properties for consistent theming
- Responsive design (mobile-first)

### Data Flow
- Mock data for now (easy to swap to API calls)
- State management via React hooks
- Forms use controlled components

## Next Steps

1. **Connect to Backend API**
   - Replace mock data in page components
   - Add API routes in `app/api/`
   - Use `fetch()` or SWR for data fetching

2. **Add Authentication**
   - Implement middleware for protected routes
   - Add login/signup pages
   - Store JWT tokens securely

3. **Enhance 3D Experience**
   - Add interactive elements to the canvas
   - Implement VR mode for supported devices
   - Create animated transitions between sections

4. **Deploy**
   - Vercel (recommended for Next.js)
   - Configure environment variables
   - Set up CI/CD pipeline

## Learn More

- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Three.js Fundamentals](https://threejs.org/manual/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
