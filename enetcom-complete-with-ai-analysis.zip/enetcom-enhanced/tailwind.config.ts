// tailwind.config.ts
import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        blue: {
          deep:   '#0a1628',
          mid:    '#0d2847',
          light:  '#1a4a8a',
          accent: '#2e86de',
          glow:   '#4da6ff',
        },
        orange: {
          deep:  '#c44400',
          main:  '#e86a00',
          light: '#ff9a3c',
          glow:  '#ffb865',
        },
        text: {
          white: '#f0f4f8',
          dim:   '#8899aa',
        }
      },
      fontFamily: {
        display: ['Orbitron', 'sans-serif'],
        body:    ['Rajdhani', 'sans-serif'],
        mono:    ['Share Tech Mono', 'monospace'],
      },
      keyframes: {
        fadeInUp: {
          '0%':   { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeInDown: {
          '0%':   { opacity: '0', transform: 'translateY(-20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        floatUp: {
          '0%':   { opacity: '0', transform: 'translateY(100vh) scale(0)' },
          '10%':  { opacity: '0.6' },
          '90%':  { opacity: '0.6' },
          '100%': { opacity: '0', transform: 'translateY(-100px) scale(1)' },
        },
        reveal: {
          '0%':   { opacity: '0', transform: 'translateY(40px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        }
      },
      animation: {
        'fade-in-up':   'fadeInUp 1s ease forwards',
        'fade-in-down': 'fadeInDown 0.8s ease forwards',
        'float-up':     'floatUp linear infinite',
        'reveal':       'reveal 0.7s ease forwards',
      },
    },
  },
  plugins: [],
}

export default config
