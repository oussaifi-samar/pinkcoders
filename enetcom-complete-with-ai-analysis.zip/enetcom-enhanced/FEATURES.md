# ENET'COM Forum Platform - Enhanced Version

This is an enhanced Next.js-based forum platform for connecting students with companies for internships, PFE projects, and job opportunities.

## New Features Added

### 🎓 Student Dashboard Enhancements

#### 1. Application Modal
- **Trigger**: Click "Apply Now" button on any offer card
- **Features**:
  - Complete application form with personal information
  - Fields: Name, Email, Phone, GPA, Major, Academic Year
  - Cover letter text area
  - CV/Resume file upload (PDF, DOC, DOCX)
  - Form validation
  - Beautiful modal UI with gradient styling

#### 2. Offer Details Modal
- **Trigger**: Click "Details" button on any offer card
- **Features**:
  - Full offer information display
  - Company details
  - Application deadline with formatted date
  - Number of applicants
  - Posted date
  - Offer status (Open/Closed)
  - Required skills with tags
  - Additional opportunity information
  - Direct "Apply Now" action from details view

### 🏢 Company Dashboard Enhancements

#### 1. Student Profiles Section
- **Access**: New "Student Profiles" tab in company dashboard
- **Features**:
  - Browse all registered student profiles
  - Student cards showing:
    - Name and avatar (initials)
    - Major and academic year
    - GPA and bio preview
    - Top 3 skills with overflow indicator
    - Application count
  - Click any profile card to view full details

#### 2. Enhanced Application Cards
- **New "View Profile" Button**: Added to each application card
- **Features**:
  - View complete student profile from application
  - Accept/Reject actions available in profile view
  - Seamless workflow between applications and profiles

#### 3. Student Profile Modal
- **Triggered by**: Clicking on student profile or "View Profile" button
- **Features**:
  - Complete student information:
    - Contact details (email, phone)
    - Academic information (GPA, Major, Year)
    - Professional bio
    - Full skills list with visual tags
    - CV download button
    - Application history statistics
    - Member since date
  - Action buttons:
    - Accept application
    - Reject application
    - Close modal

### ⚙️ Admin Dashboard Enhancements

#### 1. Manage Students Section
- **Access**: New "Manage Students" tab in admin dashboard
- **Features**:
  - Search functionality:
    - Search by name, email, or major
    - Real-time filtering
    - Result count display
  - Student management cards:
    - Avatar with initials
    - Name and major
    - Contact information (email, phone)
    - Academic stats (GPA, Year)
    - Application count
    - View full profile action
    - Delete student action (with confirmation)
  - Empty state for no search results

#### 2. Updated Statistics
- **New Stat Cards**:
  - Total Offers
  - Total Applications
  - Registered Students (new)
  - Partner Companies (new)

## Technical Implementation

### New Components Created

1. **ApplicationModal** (`/components/shared/ApplicationModal.tsx`)
   - Form-based modal for student applications
   - File upload handling
   - Form validation
   - Responsive design

2. **OfferDetailsModal** (`/components/shared/OfferDetailsModal.tsx`)
   - Detailed offer information display
   - Date formatting
   - Skills visualization
   - Call-to-action integration

3. **StudentProfileModal** (`/components/shared/StudentProfileModal.tsx`)
   - Comprehensive student profile view
   - Multiple action handlers
   - Conditional rendering for actions
   - Download functionality

### Updated Components

1. **OfferCard** (`/components/shared/OfferCard.tsx`)
   - Added `onDetails` callback prop
   - Enhanced button interactions

### New Type Definitions

**`/types/student.ts`**:
```typescript
interface StudentProfile {
  id: number
  name: string
  email: string
  phone: string
  gpa: number
  major: string
  year: number
  skills: string[]
  bio: string
  cvUrl?: string
  appliedOffers: number[]
  createdAt: string
}

interface ApplicationFormData {
  studentName: string
  studentEmail: string
  studentPhone: string
  gpa: number
  major: string
  year: number
  coverLetter: string
  cvFile?: File
}
```

### Updated Pages

1. **Student Dashboard** (`/app/student/page.tsx`)
   - Modal state management
   - Application submission handling
   - Details view handling
   - Application counter updates

2. **Company Dashboard** (`/app/company/page.tsx`)
   - Tab navigation (Applications / Student Profiles)
   - Student profile browsing
   - Profile modal integration
   - Enhanced application cards with profile viewing

3. **Admin Dashboard** (`/app/admin/page.tsx`)
   - New "Manage Students" tab
   - Search functionality
   - Student deletion with confirmation
   - Updated statistics

## Mock Data

### Student Profiles
The platform includes 5 mock student profiles with:
- Complete contact information
- Academic records
- Skills and expertise
- Professional bios
- CV references
- Application history

### Integration Points
All mock data is connected across:
- Applications referencing student IDs
- Student profiles with applied offers
- Consistent data across all dashboards

## UI/UX Improvements

### Design Consistency
- All modals use the same gradient styling
- Consistent button styles and interactions
- Uniform card layouts
- Smooth animations and transitions

### Accessibility
- Keyboard navigation support
- Click-outside-to-close modals
- Clear visual hierarchy
- Readable typography

### Responsive Design
- Mobile-friendly modals
- Adaptive grid layouts
- Flexible card designs
- Touch-friendly buttons

## Installation & Usage

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

## Future Enhancements

Potential improvements:
1. Backend API integration
2. Real file upload to cloud storage
3. Email notifications
4. Advanced search filters
5. Student profile editing
6. Company verification system
7. Application status tracking
8. Dashboard analytics
9. Export functionality
10. Real-time updates with WebSockets

## Technology Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **State Management**: React Hooks (useState)
- **UI Components**: Custom components with Tailwind

## License

MIT License - See LICENSE file for details
