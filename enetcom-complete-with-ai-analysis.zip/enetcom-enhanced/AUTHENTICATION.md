# ENET'COM Forum Platform - Authentication System

## 🔐 Authentication Overview

The platform now features a complete authentication system that manages user sessions and role-based access control.

## Login Credentials

### Demo Accounts

The system includes three pre-configured demo accounts for testing:

| Role | Email | Password | Access |
|------|-------|----------|--------|
| **Student** | `student@enetcom.tn` | Any password | Student Dashboard |
| **Company** | `company@enetcom.tn` | Any password | Company Dashboard |
| **Admin** | `admin@enetcom.tn` | Any password | Admin Dashboard |

> **Note**: For demonstration purposes, any password will work for the mock accounts. In production, this should be replaced with proper authentication.

## User Flow

### 1. Login Process
1. User visits the homepage (`/`)
2. Login page is displayed
3. User enters email and password
4. Upon successful login, user is automatically redirected to their role-specific dashboard:
   - Students → `/student`
   - Companies → `/company`
   - Admins → `/admin`

### 2. Session Management
- User session is stored in `localStorage`
- Session persists across page refreshes
- User remains logged in until they explicitly logout

### 3. Protected Routes
All dashboard pages are protected:
- Users must be authenticated to access any dashboard
- Users are automatically redirected to their appropriate dashboard based on role
- Attempting to access another role's dashboard redirects to your own

### 4. Logout
- Click the "Logout" button in the navigation bar
- Session is cleared from `localStorage`
- User is redirected to the login page

## Quick Login Feature

The login page includes a "Show Demo Credentials" button that provides quick-login buttons for each role:
- 🎓 **Student Login** - Instantly log in as a student
- 🏢 **Company Login** - Instantly log in as a company
- ⚙️ **Admin Login** - Instantly log in as an admin

## Navigation Behavior

### Before Login
- Only "Home" button is visible
- Clicking navigates to login page

### After Login
- Dashboard button for current role
- User name display (on desktop)
- Logout button

## Components

### New Components

1. **AuthContext** (`/contexts/AuthContext.tsx`)
   - Manages authentication state
   - Provides login/logout functions
   - Stores user session

2. **LoginPage** (`/components/auth/LoginPage.tsx`)
   - Login form interface
   - Quick login buttons
   - Demo credentials display
   - Error handling

3. **ProtectedRoute** (`/components/auth/ProtectedRoute.tsx`)
   - Wraps protected pages
   - Checks authentication status
   - Enforces role-based access
   - Handles redirects

### Updated Components

1. **Nav** (`/components/shared/Nav.tsx`)
   - Shows/hides elements based on auth status
   - Displays current user name
   - Logout functionality

2. **HomePage** (`/app/page.tsx`)
   - Shows login page for unauthenticated users
   - Redirects authenticated users to dashboard

3. **Dashboard Pages**
   - All wrapped with `ProtectedRoute`
   - Only accessible to appropriate role

## Authentication Flow Diagram

```
┌─────────────┐
│   Homepage  │
│     (/)     │
└──────┬──────┘
       │
       ├─── Not Authenticated ──→ Show Login Page
       │
       └─── Authenticated ──→ Redirect to Dashboard
                              │
                              ├─── Student Role ──→ /student
                              ├─── Company Role ──→ /company
                              └─── Admin Role ──→ /admin
```

## Security Considerations

### Current Implementation (Demo)
- Mock authentication (accepts any password)
- Client-side session storage
- No password encryption
- No token expiration

### Production Recommendations
1. **Backend Integration**
   - Implement proper API authentication
   - Use JWT tokens or similar
   - Secure password hashing (bcrypt, argon2)
   - Server-side session validation

2. **Security Enhancements**
   - HTTPS only
   - CSRF protection
   - Rate limiting on login attempts
   - Secure HTTP-only cookies for tokens
   - Token refresh mechanism
   - Password strength requirements
   - Account lockout after failed attempts

3. **Additional Features**
   - Password reset functionality
   - Email verification
   - Two-factor authentication (2FA)
   - Remember me functionality
   - Session timeout
   - Activity logging

## Usage Examples

### Login
```typescript
const { login } = useAuth()

const handleLogin = async () => {
  const success = await login('student@enetcom.tn', 'password')
  if (success) {
    // User is redirected automatically
  } else {
    // Show error message
  }
}
```

### Logout
```typescript
const { logout } = useAuth()

const handleLogout = () => {
  logout()
  // User is redirected to login page
}
```

### Check Authentication Status
```typescript
const { isAuthenticated, user } = useAuth()

if (isAuthenticated) {
  console.log(`Logged in as: ${user.name}`)
  console.log(`Role: ${user.role}`)
}
```

### Protect a Route
```typescript
import ProtectedRoute from '@/components/auth/ProtectedRoute'
import { UserRole } from '@/types'

export default function MyPage() {
  return (
    <ProtectedRoute allowedRole={UserRole.STUDENT}>
      {/* Page content only visible to students */}
    </ProtectedRoute>
  )
}
```

## Troubleshooting

### Cannot Access Dashboard
- Ensure you're logged in
- Check that you're using the correct role's credentials
- Clear localStorage and try logging in again
- Check browser console for errors

### Session Lost After Refresh
- This shouldn't happen with current implementation
- If it does, check if localStorage is enabled in your browser
- Try a different browser

### Stuck on Login Page
- Ensure JavaScript is enabled
- Check browser console for errors
- Try clearing browser cache and cookies

## API Integration Guide

When connecting to a real backend:

1. Update `AuthContext.tsx`:
```typescript
const login = async (email: string, password: string) => {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  })
  
  if (response.ok) {
    const data = await response.json()
    setUser(data.user)
    localStorage.setItem('token', data.token)
    return true
  }
  return false
}
```

2. Add token to API requests:
```typescript
const token = localStorage.getItem('token')
fetch('/api/offers', {
  headers: {
    'Authorization': `Bearer ${token}`
  }
})
```

3. Implement token refresh mechanism
4. Add proper error handling
5. Implement logout API call

## Testing

### Test Scenarios

1. **Login with each role**
   - Verify correct dashboard is shown
   - Check navigation updates correctly

2. **Try accessing wrong dashboard**
   - Login as student
   - Navigate to `/company`
   - Should redirect to `/student`

3. **Logout and verify**
   - Click logout
   - Should redirect to login page
   - Try accessing dashboard
   - Should redirect to login

4. **Session persistence**
   - Login
   - Refresh page
   - Should remain logged in

## License

MIT License - See LICENSE file for details
