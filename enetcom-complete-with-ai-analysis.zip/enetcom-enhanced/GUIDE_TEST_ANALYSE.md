# 🧪 Guide de Test — Analyse IA de Candidature

## 📋 Comment Tester la Fonctionnalité

### Étape 1 : Accéder au Dashboard Étudiant

1. Ouvrir l'application : `npm run dev`
2. Se connecter en tant qu'étudiant
3. Naviguer vers le Dashboard Étudiant
4. Choisir une offre (ex: "PFE — Deep Learning")
5. Cliquer sur **"Apply Now"**

---

## 🎯 Scénarios de Test

### Test 1 : Candidature Excellente (Score ≥ 85%)

**Formulaire à remplir :**

```
Full Name: Ahmed Ben Salem
Email: ahmed.salem@example.com
Phone: +216 98 765 432
GPA: 3.8
Major: Computer Science
Current Year: 5th Year

Cover Letter (copier-coller ceci) :
Je suis passionné par l'intelligence artificielle et le deep learning. 
Avec mon expérience en Python et TensorFlow acquise lors de mes 
précédents projets, j'ai développé de solides compétences en CNN 
et en traitement d'images. Mon équipe et moi avons contribué à 
un projet de classification d'images médicales qui a permis 
d'améliorer la précision de diagnostic de 15%. Je suis motivé à 
apprendre et à développer mes compétences chez Esprit dans ce 
domaine passionnant de la reconnaissance d'images.

CV: [Télécharger n'importe quel fichier PDF]
```

**Résultat attendu :**
- ✅ Score Global : 85-95%
- ✅ Probabilité : 80-95%
- ✅ Recommandation : **Fortement Recommandé 🌟**
- ✅ Points forts : GPA excellent, compétences alignées, lettre convaincante

---

### Test 2 : Candidature Moyenne (Score 60-75%)

**Formulaire à remplir :**

```
Full Name: Leila Kammoun
Email: leila.k@example.com
Phone: +216 55 123 456
GPA: 3.2
Major: Information Systems
Current Year: 3rd Year

Cover Letter :
Je suis intéressée par cette offre de PFE. J'ai étudié Python 
à l'université et j'aimerais apprendre TensorFlow. Je pense 
que ce projet serait une bonne opportunité pour moi.

CV: [Télécharger un fichier PDF]
```

**Résultat attendu :**
- ✅ Score Global : 60-75%
- ✅ Probabilité : 55-70%
- ✅ Recommandation : **Recommandé ✅**
- ✅ Suggestions : Développer la lettre, mentionner CNN

---

### Test 3 : Candidature Faible (Score < 50%)

**Formulaire à remplir :**

```
Full Name: Mohamed Trabelsi
Email: mohamed@example.com
Phone: +216 22 333 444
GPA: 2.4
Major: Business Administration
Current Year: 2nd Year

Cover Letter :
Je veux postuler pour ce stage.

CV: [Télécharger un fichier PDF]
```

**Résultat attendu :**
- ✅ Score Global : 30-45%
- ✅ Probabilité : 25-40%
- ✅ Recommandation : **À Améliorer 📈**
- ✅ Suggestions multiples : GPA, compétences, lettre, formation

---

## 🔍 Détails de l'Analyse

### Ce que le Système Vérifie

#### 1. GPA (25% du score)
- ✅ 3.8 → Excellent (95 points)
- ✅ 3.2 → Bon (85 points)
- ❌ 2.4 → Faible (30 points)

#### 2. Expérience (20% du score)
- ✅ 5ème année → 95 points
- ✅ 3ème année → 70 points
- ❌ 2ème année → 50 points

#### 3. Compétences (35% du score)
**Pour l'offre "Deep Learning" (Python, TensorFlow, CNN) :**
- ✅ Test 1 : 3/3 compétences mentionnées → 100%
- ⚠️ Test 2 : 1/3 compétences mentionnées → 33%
- ❌ Test 3 : 0/3 compétences mentionnées → 0%

#### 4. Lettre de Motivation (20% du score)
- ✅ Test 1 : 95 mots + mots-clés → 90 points
- ⚠️ Test 2 : 35 mots → 60 points
- ❌ Test 3 : 6 mots → 40 points

---

## 📊 Visualisation du Résultat

### Ce que Vous Verrez

1. **Animation du Cercle**
   - Progression de 0% au score final (2 secondes)
   - Couleur adaptée au score

2. **Badge de Recommandation**
   - 🌟 Fortement Recommandé (vert)
   - ✅ Recommandé (bleu)
   - ⚠️ Possible (jaune)
   - 📈 À Améliorer (orange)

3. **Détails par Critère**
   - Barres colorées pour chaque dimension
   - Pourcentage exact affiché

4. **Points Forts** (si score ≥ 80)
   - Liste automatique
   - Fond vert

5. **Suggestions** (si score < 80)
   - Conseils personnalisés
   - Fond orange

---

## 🎬 Séquence d'Animation

```
1. Formulaire soumis
   ↓
2. Modal se ferme (300ms)
   ↓
3. Modal de résultat apparaît (fade-in)
   ↓
4. Animation du cercle (0% → score final, 2s)
   ↓
5. Apparition des détails (après animation)
   ↓
6. Bouton "Continuer à Explorer"
```

---

## 🧮 Formule de Calcul

```typescript
Score Global = 
  (GPA_score × 0.25) + 
  (Experience_score × 0.20) + 
  (Skills_score × 0.35) + 
  (CoverLetter_score × 0.20)

Probabilité = Score Global + Random(-5, +5)
Probabilité = Math.max(10, Math.min(95, Probabilité))
```

---

## 💡 Conseils pour Obtenir un Score Élevé

### Pour Maximiser Votre Score :

**1. GPA (25%)**
- ✅ Maintenez un GPA ≥ 3.5
- ✅ Si < 3.0, compensez avec une excellente lettre

**2. Année (20%)**
- ✅ Plus vous êtes avancé, mieux c'est
- ✅ 4ème/5ème année = bonus important

**3. Compétences (35%)** ← Le Plus Important !
- ✅ Mentionnez TOUTES les compétences de l'offre
- ✅ Utilisez les mots exacts (Python, TensorFlow, etc.)
- ✅ Décrivez comment vous les avez utilisées

**4. Lettre (20%)**
- ✅ 150-300 mots idéal
- ✅ Incluez : experience, passion, skills, team, motivated
- ✅ Soyez spécifique et concret

---

## 📝 Exemple de Lettre Parfaite

```
Je suis passionné par [domaine technique]. Fort de mon experience 
en [projet 1] et [projet 2], j'ai développé de solides skills en 
[compétence 1], [compétence 2] et [compétence 3]. 

Travaillant en team sur [projet concret], nous avons contribué à 
[résultat mesurable]. Cette experience m'a permis de maîtriser 
[technologie] et de comprendre l'importance de [valeur].

Je suis motivated à learn et à develop mes compétences chez 
[entreprise]. Mon objectif est de contribute à [mission de l'offre] 
en apportant ma passion pour [domaine] et mon expertise technique.

Dedicated et rigoureux, je suis convaincu que mon profil correspond 
parfaitement à vos attentes pour ce projet.
```

**Mots-clés valorisés (détectés automatiquement) :**
- experience (x2)
- passion (x2)
- skills
- team
- motivated
- learn
- develop
- contribute
- dedicated

**Score de cette lettre : ~95/100**

---

## 🐛 Débogage

### Vérifications si Problème

**Le modal ne s'affiche pas :**
1. Vérifier la console pour erreurs
2. S'assurer que tous les champs sont remplis
3. Vérifier que le fichier CV est uploadé

**Score trop bas :**
1. Vérifier que les compétences sont mentionnées
2. Allonger la lettre (min 100 mots)
3. Améliorer le GPA dans le formulaire
4. Choisir une année plus avancée

**Score trop élevé :**
1. C'est normal si le profil est excellent !
2. Le facteur aléatoire peut ajouter +5%
3. Tester avec des profils plus faibles

---

## 📸 Captures d'Écran Recommandées

Pour documenter la fonctionnalité :

1. **Formulaire de candidature** rempli
2. **Modal de résultat** avec score élevé (≥80%)
3. **Modal de résultat** avec score moyen (60-75%)
4. **Modal de résultat** avec score faible (<50%)
5. **Animation du cercle** en cours
6. **Section "Points Forts"** visible
7. **Section "Suggestions"** visible

---

## ✅ Checklist de Test Complet

- [ ] Test candidature excellente (GPA 3.8, 5ème année)
- [ ] Test candidature moyenne (GPA 3.2, 3ème année)
- [ ] Test candidature faible (GPA 2.4, 2ème année)
- [ ] Vérifier l'animation du cercle
- [ ] Vérifier les couleurs des barres
- [ ] Vérifier les points forts affichés
- [ ] Vérifier les suggestions affichées
- [ ] Tester le bouton "Continuer"
- [ ] Tester sur mobile (responsive)
- [ ] Vérifier le compteur d'applications (+1)

---

**Bon test ! 🚀**
