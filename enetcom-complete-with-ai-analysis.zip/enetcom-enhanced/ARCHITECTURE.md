# ENET'COM Forum — Next.js 14 Architecture Guide

## Design Decisions & Rationale

| Decision | Rationale |
|---|---|
| **App Router (Next.js 14)** | Modern file-based routing with built-in layouts, loading states, and streaming. Each route is a folder with its own `page.tsx`. Server Components by default — client components opt-in with `'use client'`. |
| **Feature-based Routes** | `/student`, `/company`, `/admin` are top-level routes in `app/`. Each has its own `page.tsx`, `layout.tsx` (if needed), and `loading.tsx`. |
| **Server Components** | Static content (home page, concept cards, timeline) renders on the server. No client-side JS needed for these sections. |
| **Client Components** | Interactive UI (3D background, dashboards, forms) uses `'use client'`. Isolated to specific files — the rest stays server-rendered. |
| **Server Actions** | Form submissions and mutations use Server Actions (`'use server'`) — no API routes needed for simple CRUD. |
| **API Routes** | Complex operations live in `app/api/` with route handlers. Returns typed JSON responses. |
| **TypeScript Everywhere** | Every file is `.ts` or `.tsx`. Strict mode enabled. All models are exported from a single `types/index.ts` barrel. |
| **Tailwind CSS** | Utility-first styling. Design tokens in `tailwind.config.ts`. Custom animations via `@keyframes` in globals.css. |
| **Three.js Component** | Self-contained client component. Manages canvas, scene, and animation loop. Cleanup in `useEffect` return. |
| **React Server Components** | Data fetching happens in Server Components (async functions). No `useEffect` for data — just `await fetch()`. |
| **Middleware** | Auth checks and redirects in `middleware.ts`. Runs before routes render. |
| **Custom Hooks** | `useReveal()` for scroll animations, `useOffers()` for client-side data fetching when needed. |

---

## Folder Tree

```
src/
├── app/                           ← App Router (Next.js 14)
│   ├── layout.tsx                 ← Root layout (nav, 3D background, fonts)
│   ├── page.tsx                   ← Home page (Server Component)
│   ├── globals.css                ← Tailwind + custom animations
│   │
│   ├── student/
│   │   ├── page.tsx               ← Student dashboard (Client Component)
│   │   └── loading.tsx            ← Loading skeleton
│   │
│   ├── company/
│   │   ├── page.tsx               ← Company dashboard (Client Component)
│   │   └── loading.tsx
│   │
│   ├── admin/
│   │   ├── page.tsx               ← Admin dashboard (Client Component)
│   │   └── loading.tsx
│   │
│   └── api/                       ← API Routes (Route Handlers)
│       ├── offers/
│       │   └── route.ts
│       ├── applications/
│       │   └── route.ts
│       └── companies/
│           └── route.ts
│
├── components/
│   ├── shared/                    ← Reusable UI components
│   │   ├── Nav.tsx
│   │   ├── StatCard.tsx
│   │   ├── OfferCard.tsx
│   │   ├── ConceptCards.tsx
│   │   └── EditionsTimeline.tsx
│   │
│   └── three/
│       └── ThreeDBackground.tsx   ← Three.js canvas (Client Component)
│
├── lib/
│   ├── services/                  ← Data fetching & API calls
│   │   ├── offers.ts
│   │   ├── applications.ts
│   │   └── companies.ts
│   │
│   ├── hooks/                     ← Custom React hooks
│   │   ├── useReveal.ts
│   │   └── useOffers.ts
│   │
│   └── utils/
│       └── api.ts                 ← Typed fetch wrapper
│
├── types/
│   └── index.ts                   ← All TypeScript interfaces & enums
│
├── middleware.ts                  ← Auth & route protection
└── public/                        ← Static assets

```

---

## Route Architecture

```
/                     → app/page.tsx              (Server Component — static hero + timeline)
/student              → app/student/page.tsx      (Client Component — interactive dashboard)
/company              → app/company/page.tsx      (Client Component — forms + actions)
/admin                → app/admin/page.tsx        (Client Component — protected by middleware)

API Routes:
/api/offers           → app/api/offers/route.ts
/api/applications     → app/api/applications/route.ts
/api/companies        → app/api/companies/route.ts
```

---

## Server vs Client Components

**Server Components** (default):
- `app/page.tsx` — Home page content
- `components/shared/ConceptCards.tsx` — Static marketing content
- `components/shared/EditionsTimeline.tsx` — Data fetched server-side

**Client Components** (`'use client'`):
- `components/three/ThreeDBackground.tsx` — Three.js canvas
- `app/student/page.tsx` — Interactive dashboard with state
- `app/company/page.tsx` — Form submissions
- `app/admin/page.tsx` — Tabbed interface
- `components/shared/Nav.tsx` — Active route highlighting

---

## Data Flow

```
Server Component  →  async fetch()  →  API Route  →  Database/Service
                                    ↓
Client Component  →  useEffect() / SWR  →  API Route  →  Database/Service
                                    ↓
Server Action     →  'use server'   →  Direct database access
```
